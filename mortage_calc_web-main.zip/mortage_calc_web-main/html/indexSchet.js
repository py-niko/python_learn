import {twoSecond, sumCredit, timeCredit, sumFive, raschet, btnExcel, sumFour} from "./scripts/utils/constant.js"
import { parserNumberToRazryd } from './scripts/utils/parserNumberToRazryd.js'
import { schet } from "./scripts/utils/schet.js";
import { tableToExcel } from "./scripts/utils/tableToExcel.js"

//вызов функции разделения чисел на разряды
sumCredit.addEventListener('input', function() {
    parserNumberToRazryd(this)
})

//функция по перебору списка из schet.js и добавления этих значений в выпадающий список
schet.data.forEach(function(item){
    const option = document.createElement('option');
    option.text = item.name;
    option.value = item.name;
    option.innerHTML = item.name;
    twoSecond.appendChild(option)
});

//Кнопки которые вызывают функции клику, изменению 1
raschet.addEventListener('click', raschetSchet)
btnExcel.addEventListener('click', tableToExcel)

twoSecond.addEventListener('change', () => {
    let table = document.getElementById('paymentScheduleTable')
    table.textContent = ""
    sumFour.innerHTML='Процентная ставка: '
    sumFive.innerHTML='Доходность итого (весь срок счёта) = '
})

//функция по определнию капиталазции вкладов
function raschetSchet(evt) {
    evt.preventDefault()
    let table = document.getElementById('paymentScheduleTable')
    //устанавливаем начальные пустые значения далее при обновлении данных, старые данные будут затираться
    table.textContent = ""
    sumFour.innerHTML='Процентная ставка: '
    sumFive.innerHTML='Доходность итого (весь срок счёта) = '
    let sumSchet=sumCredit.value
    sumSchet = parseFloat(sumSchet.replace(/ /g, '')) 
    const result = schet.data.find(obj => obj.name === twoSecond.value)
    //проверка подходит ли указанная сумма введеная пользоавтелем или нет с параметром из списка.
    //в зависимости от суммы отличаются проценты
        if(sumSchet<=result.maxSumSchetOne) {
            let procent = result.procentOne
            raschetOne(sumSchet, procent)
        }
        else if(sumSchet<=result.maxSumSchetTwo ) {
            let procent = result.procentTwo
            raschetOne(sumSchet, procent)
        }
        else if(sumSchet<=result.maxSumSchetThree ) {
            let procent = result.procentThree
            raschetOne(sumSchet, procent)
        }
        else {
            alert("Не предвиденная ошибка, пожалуйста проверьте данные и Попробуйте ещё раз.")
        }
        
}

//функция по расчёту накопительного счета
function raschetOne(sumSchet, procent) {
    let paymentSchedul = [] //пустой массив куда будет записывать данные для таблицы
    let date = new Date(Date.now()) //определяем дату
    let totalPay = sumSchet //определяем сумму веденной пользователем
    for (let i = 1; i<=timeCredit.value; i++) {
        //определяем является ли год високосным
        let paymentDate = new Date(date.getFullYear(), date.getMonth() + i, date.getDate());
        if(paymentDate.getDay()===0){
            paymentDate.setDate(paymentDate.getDate()+1)
            
        }
        else if (paymentDate.getDay()===6){
            paymentDate.setDate(paymentDate.getDate()+2)
        }
        let time = paymentDate.getFullYear()%4==0?366:365
        //высчитываем платеж
        let insertPay = parseFloat((totalPay * procent) * ((time/12)/time))
        totalPay += parseFloat(insertPay)
        //записываем все данные в массив
        paymentSchedul.push({
            month:paymentDate.toLocaleDateString('ru-RU'),
            totalPayProcent:(totalPay - sumSchet).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2}),
            totalPay:totalPay.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})
        })
        
    }
    //вызов функции для построения таблицы с рассчетами
    fillTableShet(paymentSchedul)
    sumFour.innerHTML='Процентная ставка: '+ procent*100 + '%'
    sumFive.innerHTML='Доходность итого (весь срок счёта) = '+ totalPay.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})
}

//функция по построению таблицы и вывода информации пользователю по счету
function fillTableShet(paymentSchedul) {
    //создаем таблицу и шапку с названиями
    let table = document.getElementById('paymentScheduleTable')
    let headerRow = table.insertRow(0);
    let monthHeader = headerRow.insertCell(0);
    monthHeader.textContent = "Месяц";
    let insertPaymentMainShetProcent = headerRow.insertCell(1);
    insertPaymentMainShetProcent.textContent = "Размер процентов"
    let insertPaymentSchet = headerRow.insertCell(2);
    insertPaymentSchet.textContent = "Общая сумма счёта";
    //заполнение таблицы результатами
        for (let i = 0; i <paymentSchedul.length; i++) {
            let row = table.insertRow(i+1)
            let monthCell = row.insertCell(0)
            let remainingPaymnetMainSchetProcent = row.insertCell(1)
            let insertPaymentSchet = row.insertCell(2)
            
            monthCell.innerHTML = paymentSchedul[i].month
            remainingPaymnetMainSchetProcent.innerHTML=paymentSchedul[i].totalPayProcent
            insertPaymentSchet.innerHTML=paymentSchedul[i].totalPay
        }
}