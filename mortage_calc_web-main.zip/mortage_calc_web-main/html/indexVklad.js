import {
    firstOne,
    sumCredit,
    btn,
    infoVklad,
    twoSecond,
    credictProduct,
    periodOneMin,
    priodOneMax,
    procentOne,
    periodTwoMin,
    priodTwoMax,
    procentTwo,
    periodThreeMin,
    priodThreeMax,
    procentThree,
    periodFourMin,
    priodFourMax,
    procentFour,
    periodFiveMin,
    priodFiveMax,
    procentFive,
    periodSixMin,
    priodSixMax,
    procentSix,
    raschet,
    sumOne,
    sumTwo,
    sumThree,
    sumFour,
    sumFive,
    sumSix,
    sumSeven,
    threeSecond,
    fourSecond,
    profit93
} from "./scripts/utils/constant.js"

import { parserNumberToRazryd } from "./scripts/utils/parserNumberToRazryd.js"
import { vklad, period } from "./scripts/utils/vklad.js"

// ----------------------------------------
// Вспомогательные функции
// ----------------------------------------

function parseAmount(el) {
    let v = el.value || "0"
    v = v.replace(/ /g, "")
    const n = parseFloat(v)
    return isNaN(n) ? 0 : n
}

function formatMoney(n) {
    return n.toLocaleString(undefined, {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    })
}

function clearResults() {
    if (sumOne) sumOne.textContent = "= "
    if (sumTwo) sumTwo.textContent = "= "
    if (sumThree) sumThree.textContent = "= "
    if (sumFour) sumFour.textContent = "= "
    if (sumFive) sumFive.textContent = "= "
    if (sumSix) sumSix.textContent = "= "
    if (sumSeven)
        sumSeven.textContent =
            "Доходность итого (весь срок вклада) = "
    if (profit93) profit93.innerHTML = ""
}

// ----------------------------------------
// Заполнение селекторов
// ----------------------------------------

// форматирование суммы на разряды
sumCredit.addEventListener("input", function () {
    parserNumberToRazryd(this)
})

// список сроков (в днях)
function selectProgramOne() {
    const selectCredit = period.find(function (item) {
        return item.period
    }, this)

    if (!selectCredit) return

    selectCredit.period.forEach(function (item) {
        const option = document.createElement("option")
        option.text = item
        option.value = item
        firstOne.appendChild(option)
    })
}
selectProgramOne()

// список вкладов
vklad.data.forEach(function (item) {
    if (!item.name) return
    const option = document.createElement("option")
    option.text = item.name
    option.value = item.name
    option.innerHTML = item.name
    twoSecond.appendChild(option)
})

// ----------------------------------------
// Обработчики
// ----------------------------------------

btn.addEventListener("click", podborVklad)
credictProduct.addEventListener("change", resultVklad)
raschet.addEventListener("click", raschetVklad)

// очищаем результаты при смене продукта
twoSecond.addEventListener("change", () => {
    clearResults()
})

// ----------------------------------------
// Подбор вклада
// ----------------------------------------

function podborVklad(evt) {
    evt.preventDefault()

    let sumVklad = parseAmount(sumCredit)
    let timeVklad = parseFloat(firstOne.value) || 0

    let capitality = threeSecond.value === "Да"
    let popolnenie = fourSecond.value === "Да"

    infoVklad.innerHTML =
        "Вклад не найден, пожалуйста выберите другие параметры"

    for (let i of vklad.data) {
        if (!i.name || i.name === "Выберите вклад") continue

        const matchPeriod =
            timeVklad === i.periodOneMax ||
            timeVklad === i.periodTwoMax ||
            timeVklad === i.periodThreeMax ||
            timeVklad === i.periodFourMax ||
            timeVklad === i.periodFiveMax ||
            timeVklad === i.periodSixMax

        if (
            matchPeriod &&
            capitality === i.capitalyti &&
            popolnenie === i.popolnenie
        ) {
            if (sumVklad >= i.minSumVklad) {
                infoVklad.innerHTML = ""
                infoVklad.innerHTML +=
                    "Вам подойдет: " +
                    i.name +
                    ", " +
                    i.about +
                    "<br><br>"
            } else {
                infoVklad.innerHTML =
                    "Ошибка, минимальная сумма вклада не соотвествует ни одному из продуктов банка по заданным параметрам."
            }
        }
    }
}

// ----------------------------------------
// Расчёт с капитализацией
// ----------------------------------------

function raschetCapitality(result) {
    const principal = parseAmount(sumCredit)
    let total = principal
    let date = new Date()

    const segments = [
        {
            min: result.periodOneMin,
            max: result.periodOneMax,
            percent: result.procentOne,
            sumEl: sumOne
        },
        {
            min: result.periodTwoMin,
            max: result.periodTwoMax,
            percent: result.procentTwo,
            sumEl: sumTwo
        },
        {
            min: result.periodThreeMin,
            max: result.periodThreeMax,
            percent: result.procentThree,
            sumEl: sumThree
        },
        {
            min: result.periodFourMin,
            max: result.periodFourMax,
            percent: result.procentFour,
            sumEl: sumFour
        },
        {
            min: result.periodFiveMin,
            max: result.periodFiveMax,
            percent: result.procentFive,
            sumEl: sumFive
        },
        {
            min: result.periodSixMin,
            max: result.periodSixMax,
            percent: result.procentSix,
            sumEl: sumSix
        }
    ]

    let prevMax = 0
    let totalProfit = 0

    segments.forEach((seg) => {
        if (
            !seg.sumEl ||
            !seg.max ||
            !seg.percent ||
            seg.max <= 0
        ) {
            if (seg.sumEl) seg.sumEl.textContent = "= "
            return
        }

        const range =
            prevMax === 0 ? seg.max : Math.max(seg.max - prevMax, 0)

        let n = Math.round(range / result.periodPay)

        for (let i = 0; i < n; i++) {
            date.setDate(date.getDate() + result.periodPay)
            const daysInYear =
                date.getFullYear() % 4 === 0 ? 366 : 365
            const interest =
                total *
                seg.percent *
                (result.periodPay / daysInYear)
            total += interest
        }

        const currentProfit = total - principal
        const profitSegment = currentProfit - totalProfit
        totalProfit = currentProfit

        seg.sumEl.textContent = "= " + formatMoney(profitSegment)
        prevMax = seg.max
    })

    sumSeven.textContent =
        "Доходность итого (весь срок вклада) = " +
        formatMoney(totalProfit)
}

// ----------------------------------------
// Расчёт без капитализации
// ----------------------------------------

function raschetNoCapitality(result) {
    const principal = parseAmount(sumCredit)
    let date = new Date()

    const segments = [
        {
            min: result.periodOneMin,
            max: result.periodOneMax,
            percent: result.procentOne,
            sumEl: sumOne
        },
        {
            min: result.periodTwoMin,
            max: result.periodTwoMax,
            percent: result.procentTwo,
            sumEl: sumTwo
        },
        {
            min: result.periodThreeMin,
            max: result.periodThreeMax,
            percent: result.procentThree,
            sumEl: sumThree
        },
        {
            min: result.periodFourMin,
            max: result.periodFourMax,
            percent: result.procentFour,
            sumEl: sumFour
        },
        {
            min: result.periodFiveMin,
            max: result.periodFiveMax,
            percent: result.procentFive,
            sumEl: sumFive
        },
        {
            min: result.periodSixMin,
            max: result.periodSixMax,
            percent: result.procentSix,
            sumEl: sumSix
        }
    ]

    let prevMax = 0
    let totalInterest = 0

    segments.forEach((seg) => {
        if (!seg.sumEl || !seg.max || !seg.percent || seg.max <= 0) {
            if (seg.sumEl) seg.sumEl.textContent = "= "
            return
        }

        const range = prevMax === 0 ? seg.max : Math.max(seg.max - prevMax, 0)
        if (range <= 0) {
            seg.sumEl.textContent = "= "
            return
        }

        let interestSegment = 0

        if (result.name === "ВКЛАД НАРОДНЫЙ") {
            const daysInYear = date.getFullYear() % 4 === 0 ? 366 : 365
            interestSegment = principal * seg.percent * (range / daysInYear)
            date.setDate(date.getDate() + range)
        } else {
            const n = Math.round(range / result.periodPay)
            for (let i = 0; i < n; i++) {
                date.setDate(date.getDate() + result.periodPay)
                const daysInYear =
                    date.getFullYear() % 4 === 0 ? 366 : 365
                const interest =
                    principal *
                    seg.percent *
                    (result.periodPay / daysInYear)
                interestSegment += interest
            }
        }

        totalInterest += interestSegment
        seg.sumEl.textContent = "= " + formatMoney(interestSegment)
        prevMax = seg.max
    })

    sumSeven.textContent =
        "Доходность итого (весь срок вклада) = " +
        formatMoney(totalInterest)
}


function raschetVklad(evt) {
    evt.preventDefault()

    const sumVklad = parseAmount(sumCredit)
    const result = vklad.data.find(
        (obj) => obj.name === credictProduct.value
    )

    if (!result) {
        alert("Пожалуйста, выберите вклад")
        return
    }

    if (sumVklad < result.minSumVklad) {
        alert(
            "Ошибка, минимальная сумма вклада не соотвествует выбранному продукту" +
                "\nМин сумма продукта: " +
                result.minSumVklad.toLocaleString() +
                "\nВаша сумма: " +
                sumVklad.toLocaleString()
        )
        return
    }

    clearResults()

    if (result.capitalyti === true) {
        raschetCapitality(result)
    } else {
        raschetNoCapitality(result)
    }
    if (result.name ==="ВКЛАД НАРОДНЫЙ") {
        raschetNarodniyFirst93(result)
    } else {
        profit93.innerHTML = ""
    }

}

// ----------------------------------------
// Заполнение периодов при выборе вклада
// ----------------------------------------

function resultVklad() {
    const result = vklad.data.find(
        (obj) => obj.name === credictProduct.value
    )

    if (!result || twoSecond.value === "Выберите вклад") {
        periodOneMin.value = 0
        priodOneMax.value = 0
        procentOne.value = 0
        periodTwoMin.value = 0
        priodTwoMax.value = 0
        procentTwo.value = 0
        periodThreeMin.value = 0
        priodThreeMax.value = 0
        procentThree.value = 0
        periodFourMin.value = 0
        priodFourMax.value = 0
        procentFour.value = 0
        periodFiveMin.value = 0
        priodFiveMax.value = 0
        procentFive.value = 0
        periodSixMin.value = 0
        priodSixMax.value = 0
        procentSix.value = 0
        clearResults()
        return
    }

    periodOneMin.value = result.periodOneMin || 0
    priodOneMax.value = result.periodOneMax || 0
    procentOne.value = result.procentOne
        ? (result.procentOne * 100).toFixed(2)
        : 0

    periodTwoMin.value = result.periodTwoMin || 0
    priodTwoMax.value = result.periodTwoMax || 0
    procentTwo.value = result.procentTwo
        ? (result.procentTwo * 100).toFixed(2)
        : 0

    periodThreeMin.value = result.periodThreeMin || 0
    priodThreeMax.value = result.periodThreeMax || 0
    procentThree.value = result.procentThree
        ? (result.procentThree * 100).toFixed(2)
        : 0

    periodFourMin.value = result.periodFourMin || 0
    priodFourMax.value = result.periodFourMax || 0
    procentFour.value = result.procentFour
        ? (result.procentFour * 100).toFixed(2)
        : 0

    periodFiveMin.value = result.periodFiveMin || 0
    priodFiveMax.value = result.periodFiveMax || 0
    procentFive.value = result.procentFive
        ? (result.procentFive * 100).toFixed(2)
        : 0

    periodSixMin.value = result.periodSixMin || 0
    priodSixMax.value = result.periodSixMax || 0
    procentSix.value = result.procentSix
        ? (result.procentSix * 100).toFixed(2)
        : 0

    clearResults()
}

// Доход за первые 3 периода (1–93 дней) только для вклада "Народный"
// function raschetNarodniyFirst93() {

//     if (credictProduct.value !== 'ВКЛАД НАРОДНЫЙ') {
//         profit93.innerHTML = '';
//         return;
//     }

//     const result = vklad.data.find(obj => obj.name === 'ВКЛАД НАРОДНЫЙ');

//     let baseSum = parseFloat(sumCredit.value.replace(/ /g, ''));
//     if (!baseSum || isNaN(baseSum)) {
//         profit93.innerHTML = '';
//         return;
//     }

//     let date = new Date();
//     let daysYear = date.getFullYear() % 4 === 0 ? 366 : 365;
//     let profit = 0;

//     // ПЕРИОД 1: 1–30 дней
//     let days1 = result.periodOneMax - result.periodOneMin + 1;
//     let add1 = baseSum * result.procentOne * (days1 / daysYear);
//     profit += add1;

//     // ПЕРИОД 2: 31–61 дней
//     let days2 = result.periodTwoMax - result.periodTwoMin + 1;
//     let add2 = baseSum * result.procentTwo * (days2 / daysYear);
//     profit += add2;

//     // ПЕРИОД 3: 62–93 дней
//     let days3 = result.periodThreeMax - result.periodThreeMin + 1;
//     let add3 = baseSum * result.procentThree * (days3 / daysYear);
//     profit += add3;

//     profit93.innerHTML =
//         'Доход за первые три периода (93 дня): <b>' +
//         profit.toLocaleString(undefined, {minimumFractionDigits:2, maximumFractionDigits:2}) +
//         ' ₽</b>';
// }

function raschetNarodniyFirst93(result) {

    if (!result || result.name !== "ВКЛАД НАРОДНЫЙ") {
        profit93.innerHTML = ""
        return
    }

    // Считываем доходы из DOM (значения по периодам уже посчитаны выше)
    const p1 = parseFloat((sumOne.textContent || "").replace(/[^0-9.,-]/g, "").replace(",", ".")) || 0
    const p2 = parseFloat((sumTwo.textContent || "").replace(/[^0-9.,-]/g, "").replace(",", ".")) || 0
    const p3 = parseFloat((sumThree.textContent || "").replace(/[^0-9.,-]/g, "").replace(",", ".")) || 0

    const total = p1 + p2 + p3

    profit93.innerHTML =
        `Доход за первый период (93 дня) только для вклада "Народный":
        <b>${total.toLocaleString(undefined, {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        })} ₽</b>`
}