import { creditProduct, initialCreditGos } from "./scripts/utils/constance.js";
import {firstOne, twoSecond, paramentGroup, btn, btnExcel, btnSelectGroupAdd,
btnSelectGroupRemode, addSubmitElectons,
addSubmitStrahovka, deleteSubmitElectons, deleteSubmitStrahovka, celsProgram,
credictProduct, sumCredit, costHouse, timeCredit, paramentGroups,
electronSt, noStrahovkaSt, monthPayment, pereplata, resultStavka,
resultProduct, resultProgramma, resultKZ,  KZminZnachenie, KZmaxZnachenie} from "./scripts/utils/constant.js"
import { parserNumberToRazryd } from './scripts/utils/parserNumberToRazryd.js'
import { popupOpen, popupClose } from './scripts/utils/popup.js'
import { addBtnElectrons, addBtnStrahovka, deleteBtnElectrons, deleteBtnStrahovka} from './scripts/utils/addStavki.js'
import { tableToExcel } from "./scripts/utils/tableToExcel.js"
import { enableValidation } from './scripts/utils/formValidator.js'
import { resetPayment } from './scripts/utils/resetPayment.js'
import { fillTable } from "./scripts/utils/fillTable.js"
import { selectRemoveGroup } from './scripts/utils/selectRemoveGroup.js'
import { selectCelsTwo } from './scripts/utils/selectCelsTwo.js'

//Кнопки которые вызывают функции клику, изменению 
btn.addEventListener('click', viborGroup)
btnExcel.addEventListener('click', tableToExcel)

addSubmitElectons.addEventListener('click', addBtnElectrons)
addSubmitStrahovka.addEventListener('click', addBtnStrahovka)

deleteSubmitElectons.addEventListener('click', deleteBtnElectrons)
deleteSubmitStrahovka.addEventListener('click', deleteBtnStrahovka)

btnSelectGroupAdd.addEventListener('click', popupOpen)
btnSelectGroupRemode.addEventListener('click', popupClose)

//функция по сохранению данных повышающх и понижающих ставку при изменении цели продукта (селектор 2)
function selectProgramTwo() {
    const result = creditProduct.find(obj => obj.program === celsProgram.value && obj.name === credictProduct.value)

    if(electronSt.value==0) {
        electronSt.value=0
    }
    else {
        electronSt.value = result.procentDownElectrons*100
    }
    
    if (noStrahovkaSt.value==0) {
        noStrahovkaSt.value==0
    }
    else {
        noStrahovkaSt.value = parseFloat((result.procentUP*100).toFixed(3))
    }

}

//функция по перебору списка из constance.js и добавления этих значений в выпадающий список

initialCreditGos.forEach(function(item){
    const option = document.createElement('option');
    option.text = item.program
    option.value = item.program;
    option.innerHTML = item.program;
    firstOne.appendChild(option)
});

//функция позволяющая определить что выбрано из выпадающего списка и установка начальных аттрибутов выбранной программы

function selectProgramOne () {
    let selectCredit = initialCreditGos.find(function(item) {
        return item.program === this.value
    }, this)
    timeCredit.value=''
    twoSecond.innerHTML=''
    paramentGroup.innerHTML=''
    selectCredit.product.forEach(function(item){
    const option = document.createElement('option');
    option.text=item
    option.value=item
    twoSecond.appendChild(option)
    })
    resetPayment()
}

//вызов функции разделения чисел на разряды в сумме кредита и в стоимости недвижимости
sumCredit.addEventListener('input', function() {
    parserNumberToRazryd(this)
})
costHouse.addEventListener('input', function() {
    parserNumberToRazryd(this)
})

//вызов функций по выбору селекторов
firstOne.addEventListener('change', selectProgramOne)

paramentGroup.addEventListener('change', selectRemoveGroup)

twoSecond.addEventListener('change', selectCelsTwo)
twoSecond.addEventListener('change', selectProgramTwo)
//функция по выводу информации об ипоетке пользователю
function resultingCredit(newSumCredit,month, procent, kz) {

    let paymentSchedul = [] //пустой массив куда будет записывать данные для таблицы
    let remaingPrinciple=parseFloat(newSumCredit) //переменная получающее значение от пользовтаеля в формале float
    let monthlyIntersertRate = (procent/100) / 12 //определяем ежемесячную процентную ставку
    let monthlyPayment = newSumCredit * monthlyIntersertRate / ( 1 - Math.pow(1 + monthlyIntersertRate, -month))
    //функция по обнулнию расчётов для проведения новых расчётов 
    resetPayment()
    //запись в массив данных по кредиту по месяцам которые потом будут выводиться в таблицу
    for(let i = 1; i<=month; i++){
        let insertPayment = parseFloat(remaingPrinciple * monthlyIntersertRate)
        let principalPaymnet = parseFloat(monthlyPayment-insertPayment)
        let monthOpata = parseFloat(insertPayment+principalPaymnet)
        remaingPrinciple -= principalPaymnet
        let principalPaymnetMainCredit = (remaingPrinciple + principalPaymnet)
        paymentSchedul.push({
        month:i,
        principalPaymnet:principalPaymnet.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2}),
        principalPaymnetMainCredit:principalPaymnetMainCredit.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2}),
        insertPayment:insertPayment.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2}),
        monthOpata:monthOpata.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2}),
        remaingPrinciple:Math.abs(remaingPrinciple).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})
    })
    }
    //вывод на страницу данных (описание смотреть в indexIpoteka.js)
    let addTextMonthPayment = ((remaingPrinciple*monthlyIntersertRate)+(monthlyPayment-remaingPrinciple*monthlyIntersertRate)).toFixed(2)
    let parseAddTextMonthPayment = parseFloat(addTextMonthPayment).toLocaleString()
    monthPayment.textContent += parseAddTextMonthPayment

    let addTextPereplata = parseFloat((addTextMonthPayment*month-newSumCredit).toFixed(2)).toLocaleString()
    pereplata.textContent += addTextPereplata

    let addTextResultStavka = procent.toFixed(2) + '%'
    resultStavka.textContent += addTextResultStavka

    let addTextResultProduct = credictProduct.value
    resultProgramma.textContent += addTextResultProduct

    let addTextResultProgramma = celsProgram.value
    resultProduct.textContent += addTextResultProgramma

    let addTextTesultKZ = kz + '%'
    resultKZ.textContent += addTextTesultKZ
    //вызов функции по созданию таблицы
    fillTable(paymentSchedul)
}

//функция по определению КЗ и вызов функции выбора срока
export function viborGroup(evt) {
    evt.preventDefault()
    let newSumCredit=sumCredit.value
    newSumCredit = parseFloat(newSumCredit.replace(/ /g, ''))
    let newCostHous=costHouse.value
    newCostHous = parseFloat(newCostHous.replace(/ /g, ''))
    const sum = 1000000;
    const ont = parseInt(paramentGroups.value)
    const result = creditProduct.find(obj => obj.program === celsProgram.value && obj.name === credictProduct.value)
    const kz = (parseFloat(newSumCredit/newCostHous)*100).toFixed(3)

    switch (ont) {
        case 1:
            if(result.minGroup<=kz && kz<=result.groupOne)
            {
                viborMonth()
            }
            else if (kz<result.minGroup){
                alert(KZminZnachenie + result.minGroup + '\nВаше К/З: ' + kz)
            }

            else{
                alert(KZmaxZnachenie + result.groupOne + '\nВаше К/З: ' + kz)
            }
        break
        case 2:
            if(result.minGroup<=kz && kz<=result.groupTwo)
            {
                viborMonth()
            }
            else if (kz<result.minGroup){
                alert(KZminZnachenie + result.minGroup + '\nВаше К/З: ' + kz)
            }
            else {
                alert(KZmaxZnachenie + result.groupTwo + '\nВаше К/З: ' + kz)
            }
        break
        case 3:
            if(result.minGroup<=kz && kz<=result.groupThree)
            {
                viborMonth()
            }
            else if(kz<result.minGroup) {
                alert(KZminZnachenie + result.minGroup + '\nВаше К/З: ' + kz)
            }
            else {
                alert(KZmaxZnachenie + result.groupThree + '\nВаше К/З: ' + kz)
            }
        break     
        case 4:
            switch(true){
                case (kz<=result.gruopFourUslovia && newSumCredit<=sum):
                    viborMonth() 
                     
                break
                case (result.minGroup<=kz && kz<=result.groupFour):
                    viborMonth()
                break
                case (kz>result.gruopFourUslovia && newSumCredit<=sum):
                    alert(KZminZnachenie + result.gruopFourUslovia + '\nВаше К/З: ' + kz)
                break
                case (kz<result.minGroup):
                    alert(KZminZnachenie + result.minGroup + '\nВаше К/З: ' + kz)
                break
                default:alert(KZmaxZnachenie + result.groupFour + '\nВаше К/З: ' + kz)
            }
        break
        case 5:
            if(result.minGroup<=kz && kz<=result.groupFive)
            {
                viborMonth()
            }
            else if (kz<result.minGroup){
                alert(KZminZnachenie + result.minGroup + '\nВаше К/З: ' + kz)
            }
            else {
                alert(KZmaxZnachenie + result.groupFive + '\nВаше К/З: ' + kz)
            }
        break
        case 6:
            if(result.minGroup<=kz && kz<=result.groupSix)
            {
                viborMonth()
            }
            else if (kz<result.minGroup){
                alert(KZminZnachenie + result.minGroup + '\nВаше К/З: ' + kz)
            }
            else {
                alert(KZmaxZnachenie + result.groupSix + '\nВаше К/З: ' + kz)
            }
        break
        case 7:
            if(result.minGroup<=kz && kz<=result.groupSeven)
            {
                viborMonth()
            }
            else if (kz<result.minGroup){
                alert(KZminZnachenie + result.minGroup + '\nВаше К/З: ' + kz)
            }
            else {
                alert(KZmaxZnachenie + result.groupSeven + '\nВаше К/З: ' + kz)
            }
        break
        case 8:
            if(result.minGroup<=kz && kz<=result.groupEight)
            {
                viborMonth()
            }
            else if (kz<result.minGroup){
                alert(KZminZnachenie + result.minGroup + '\nВаше К/З: ' + kz)
            }
            else {
                alert(KZmaxZnachenie + result.groupEight + '\nВаше К/З: ' + kz)
            }
        break
    }
}

//функция по опредедению повышающего параметра процента основываясь на сроке кредита
function viborMonth() {
        const month = parseInt(timeCredit.value)*12
        const result = creditProduct.find(obj => obj.program === celsProgram.value && obj.name === credictProduct.value)
        let time;
        if((month/12)>result.maxAge) {
            alert('Количество лет превышает допустимое значение необходимо уменьшить срок кредита \nМаксимальный срок кредита: ' + result.maxAge)
        }
        else{
            switch (true) {
                case month>=12 && month<=48:
                    time = result.timeOne
                   sendForm(month, time)
                break
                case month>=49 && month<=120:
                    time = result.timeSecond
                    sendForm(month, time)
                break
                case month>=121 && month<=240:
                    time = result.timeTherty
                   sendForm(month, time)
                break
                case month>=241 && month<=360:
                    time = result.timeFoty
                    sendForm(month, time)
                break
            }
        }
}

//функция по определению повышающей ставки по КЗ по нормативам
function sendForm(month, time) {
    const result = creditProduct.find(obj => obj.program === celsProgram.value && obj.name === credictProduct.value)
    const electronStNum = parseFloat(electronSt.value)
    const noStrahovlaStNum = parseFloat(noStrahovkaSt.value)
    let newSumCredit=sumCredit.value
    newSumCredit = parseFloat(newSumCredit.replace(/ /g, ''))
    let newCostHous=costHouse.value
    newCostHous = parseFloat(newCostHous.replace(/ /g, ''))
    const kz = (parseFloat(newSumCredit/newCostHous)*100).toFixed()

    let procent;
    switch (true){
                case kz>=10 && kz<=15:
                    procent=(result.procent+time+result.kZ1-(electronStNum/100)+(noStrahovlaStNum/100))*100
                    resultingCredit(newSumCredit,month, procent, kz)

                break
                case kz>=16 && kz<=50:
                    procent=(result.procent+time+result.kZ2-(electronStNum/100)+(noStrahovlaStNum/100))*100
                    resultingCredit(newSumCredit,month, procent, kz)
                break
                case kz>=51 && kz<=70:
                    procent= (result.procent+time+result.kZ3-(electronStNum/100)+(noStrahovlaStNum/100))*100
                    resultingCredit(newSumCredit,month, procent, kz)

                break
                case kz>=71 && kz<=80:
                    procent=(result.procent+time+result.kZ4-(electronStNum/100)+(noStrahovlaStNum/100))*100
                    resultingCredit(newSumCredit,month, procent, kz)
                break
                case kz>=81:
                    procent=(result.procent+time+result.kZ5-(electronStNum/100)+(noStrahovlaStNum/100))*100
                    resultingCredit(newSumCredit,month, procent, kz)
                break
                default:
                alert('К/З меньше минимального, необходимо увеличить К/З \nМинимальное К/З = 10\nНа данный момент К/З: ' + kz)
    }
}
//вызов функции по валидации формы
enableValidation()
