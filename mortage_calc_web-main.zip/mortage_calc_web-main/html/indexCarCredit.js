import { CarCredit } from "./scripts/utils/car.js";
import {firstOne, btn, btnExcel, addSubmitZarplata, addSubmitKi, addSubmitElectons,
addSubmitStrahovka, deleteSubmitZarplata, deleteSubmitKi,
deleteSubmitElectons, deleteSubmitStrahovka, celsProgram,
sumCredit, costHouse, timeCredit, zarplataSt,
kiSt, electronSt, noStrahovkaSt, monthPayment, pereplata, resultStavka,
resultProduct, resultKZ} from "./scripts/utils/constant.js"
import { parserNumberToRazryd } from './scripts/utils/parserNumberToRazryd.js'
import { addBtnCarZarplata, addBtnCarKi, addBtnCarElectrons, addBtnKASKO,
deleteBtnCarZarplata, deleteBtnCarKi, deleteBtnCarElectrons, deleteBtnKASKO } from './scripts/utils/addStavki.js'
import { tableToExcel } from "./scripts/utils/tableToExcel.js"
import { resetPaymentCarCredit } from './scripts/utils/resetPayment.js'
import { fillTable } from "./scripts/utils/fillTable.js";
import { isValidAgeCarCredit } from "./scripts/utils/formValidator.js";

let minCarCr; //переменная для установление минимальной суммы кредита
function resultingCar(result) { //передаем данные в функцию из списка в перменной result
    minCarCr=result.minCredit //записываем мин.сумму из списка
    sumCredit.setAttribute('min', minCarCr) //установка аттрибутов
    sumCredit.setAttribute('value', minCarCr)
}

//Кнопки которые вызывают функции клику, изменению 
btn.addEventListener('click', viborMonth)
btnExcel.addEventListener('click', tableToExcel)
addSubmitZarplata.addEventListener('click', addBtnCarZarplata)
addSubmitKi.addEventListener('click', addBtnCarKi)
addSubmitElectons.addEventListener('click', addBtnCarElectrons)
addSubmitStrahovka.addEventListener('click', addBtnKASKO)
deleteSubmitZarplata.addEventListener('click', deleteBtnCarZarplata)
deleteSubmitKi.addEventListener('click', deleteBtnCarKi)
deleteSubmitElectons.addEventListener('click', deleteBtnCarElectrons)
deleteSubmitStrahovka.addEventListener('click', deleteBtnKASKO)
timeCredit.addEventListener('input', isValidAgeCarCredit)
firstOne.addEventListener('change', selectProgramOne)

//вызов функции разделения чисел на разряды в сумме кредита и в стоимости автокредита
sumCredit.addEventListener('input', function() {
    parserNumberToRazryd(this)
})
costHouse.addEventListener('input', function() {
    parserNumberToRazryd(this)
})

//.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})
//функция по перебору списка из CarCredit.js и добавления этих значений в выпадающий список
CarCredit.data.forEach(function(item){
    const option = document.createElement('option');
    option.text = item.name
    option.value = item.name;
    option.innerHTML = item.name;
    firstOne.appendChild(option)

});

//функция позволяющая определить что выбрано из выпадающего списка и установка начальных аттрибутов выбранной программы
function selectProgramOne () {
    const result = CarCredit.data.find(obj => obj.name === celsProgram.value)
    noStrahovkaSt.value=0
    sumCredit.value=result.minCredit
    timeCredit.value = result.minAge
    timeCredit.setAttribute('min', result.minAge)
    timeCredit.setAttribute('max', result.maxAge)
    resultingCar(result)
    
}


//функция по выводу информации об Автокредите пользователю
function resultingCredit(newSumCredit,month, procent, kz) {
    
    let paymentSchedul = [] //пустой массив куда будет записывать данные для таблицы
    let remaingPrinciple=parseFloat(newSumCredit) //переменная получающее значение от пользовтаеля в формале float
    let monthlyIntersertRate = (procent/100) / 12 //определяем ежемесячную процентную ставку
    let monthlyPayment = newSumCredit * monthlyIntersertRate / ( 1 - Math.pow(1 + monthlyIntersertRate, -month)) //определяем ежемесячный платеж
    //функция по обнулнию расчётов для проведения новых расчётов 
    resetPaymentCarCredit()
    //запись в массив данных по кредиту по месяцам которые потом будут выводиться в таблицу
    for(let i = 1; i<=month; i++){
        let insertPayment = parseFloat(remaingPrinciple * monthlyIntersertRate)
        let principalPaymnet = parseFloat(monthlyPayment-insertPayment)
        let monthOpata = parseFloat(insertPayment+principalPaymnet)
        remaingPrinciple -= principalPaymnet
        let principalPaymnetMainCredit = (remaingPrinciple + principalPaymnet)
        paymentSchedul.push({
        month:i,
        principalPaymnet:principalPaymnet.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2}),
        principalPaymnetMainCredit:principalPaymnetMainCredit.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2}),
        insertPayment:insertPayment.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2}),
        monthOpata:monthOpata.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2}),
        remaingPrinciple:Math.abs(remaingPrinciple).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})
    })
    }
    //вывод на страницу данных 
    let addTextMonthPayment = ((remaingPrinciple*monthlyIntersertRate)+(monthlyPayment-remaingPrinciple*monthlyIntersertRate)).toFixed(2)
    //ежемесячный платёж
    let parseAddTextMonthPayment = parseFloat(addTextMonthPayment).toLocaleString()
    monthPayment.textContent += parseAddTextMonthPayment
    //переплата
    let addTextPereplata = parseFloat((addTextMonthPayment*month-newSumCredit).toFixed(2)).toLocaleString()
    pereplata.textContent += addTextPereplata
    // процентая ставка
    let addTextResultStavka = procent.toFixed(2) + '%'
    resultStavka.textContent += addTextResultStavka
    //программа
    let addTextResultProduct = celsProgram.value
    resultProduct.textContent += addTextResultProduct
    // КЗ в %
    let addTextTesultKZ = kz + '%'
    resultKZ.textContent += addTextTesultKZ
    //вызов функции по созданию таблицы и передача массива с данными
    fillTable(paymentSchedul)
}

//функция по опредедению повышающего параметра процента основываясь на сроке кредита
function viborMonth(evt) { 
        evt.preventDefault()
        const month = parseInt(timeCredit.value) //получаем месяца
        const result = CarCredit.data.find(obj => obj.name === celsProgram.value) //определяем какая программа выбрана
        let time;
        if((month)>result.maxAge) {
            alert('Количество лет превышает допустимое значение необходимо уменьшить срок кредита \nМаксимальный срок кредита: ' + result.maxAge)
        }
        else{ //в зависимости от введеного месяца получаем повышение ставки и передпчи данных о месячах и повышеющей ставки в следующую функцию
            switch (true) {
                case month>=6 && month<=12:
                    time = result.timeOne
                   sendForm(month, time)
                break
                case month>=13 && month<=60:
                    time = result.timeSecond
                    sendForm(month, time)
                break
                case month>=61 && month<=84:
                    time = result.timeTherty
                   sendForm(month, time)
                break
            default:
                alert('Количество лет меньше допустимое значение необходимо увеличить срок кредита \nминимальный срок кредита: ' + result.minAge)
            }
        }
}

//функция по определению повышающей ставки по КЗ по нормативам
function sendForm(month, time) {
    const zarplataStNum = parseFloat(zarplataSt.value) //получаем значение зп-клиент или нет
    const result = CarCredit.data.find(obj => obj.name === celsProgram.value)
    const kiStNum = parseFloat(kiSt.value) // хорошая КИ
    const electronStNum = parseFloat(electronSt.value) //сотрудник банка
    const noStrahovlaStNum = parseFloat(noStrahovkaSt.value) //отказ от КАСКО
    let newSumCredit=sumCredit.value //стоимость кредита
    newSumCredit = parseFloat(newSumCredit.replace(/ /g, ''))//удаляем все пробелы между числами 
    let newCostHous=costHouse.value //стоимость машины
    newCostHous = parseFloat(newCostHous.replace(/ /g, '')) //удаляем все проблемы
    const kz = (parseFloat(newSumCredit/newCostHous)*100).toFixed() //определяем КЗ
    let kzNum = parseFloat(kz);

    if (!isNaN(kzNum) && kzNum > 70) {
        const modal = document.getElementById("carKZModal");
        modal.style.display = "flex";
    }
    //вызов результирующей функции по передача данных (стоимость кредита, количества лет в месяцах, окончательный процент, и КЗ)
    let procent;
    switch (true){ //в зависимости от КЗ производится расчет процентной ставки
                case kz>=0 && kz<=25:
                    //получаем базовую ставку и к ней уже добавляем все оставшиеся дополнительные понижающее или повышающие коэф.
                    procent=(result.procent+time+result.kZ1-(zarplataStNum/100)-(kiStNum/100)-(electronStNum/100)+(noStrahovlaStNum/100))*100
                    resultingCredit(newSumCredit,month, procent, kz)

                break
                case kz>=26 && kz<=50:
                    procent=(result.procent+time+result.kZ2-(zarplataStNum/100)-(kiStNum/100)-(electronStNum/100)+(noStrahovlaStNum/100))*100
                    resultingCredit(newSumCredit,month, procent, kz)
                break
                case kz>=51:
                    procent=(result.procent+time+result.kZ3-(zarplataStNum/100)-(kiStNum/100)-(electronStNum/100)+(noStrahovlaStNum/100))*100
                    resultingCredit(newSumCredit,month, procent, kz)
                break
                default:
                alert('К/З меньше минимального, необходимо увеличить К/З \nМинимальное К/З = 10\nНа данный момент К/З: ' + kz)
    }
}

//Валидация форм
//функция по определению сумму кредита с минимальной и максимальной
const isValid = (formElement, inputElement) => {
    
    let sum = parseFloat(inputElement.value.replace(/ /g, ''))//удаляем все пробелы между числами  и записываем это значение в переменную
    const result = CarCredit.data.find(obj => obj.name === celsProgram.value)
    if (sum<minCarCr) { //если сумма меньше минимальной вызвать функцию с ошибкой
        showInputErrorMin(formElement, inputElement, inputElement.validationMessage, result)
    }
    else if (sum>result.maxCredit) {
        showInputErrorMax(formElement, inputElement, inputElement.validationMessage, result)
    }
    else { //если все ок, вызвать функцию, которая уберет все ошибки.
        hidleInputError(formElement, inputElement)
    }

}

//функция вывода ошибки мин. сум. кредита
const showInputErrorMin = (formElement, inputElement, errorMessage, result) => {
    const errorElement = formElement.querySelector(`.${inputElement.id}-error`)
    inputElement.classList.add('popup__input-errorSa')
    errorElement.textContent = errorMessage;
    errorElement.classList.add('popup__input-error_visible');
    errorElement.textContent = 'Минимальная сумма: ' + minCarCr.toLocaleString()
}
//функция вывода ошибки макс. сум. кредита
const showInputErrorMax = (formElement, inputElement, errorMessage, result) => {
    const errorElement = formElement.querySelector(`.${inputElement.id}-error`)
    inputElement.classList.add('popup__input-errorSa')
    errorElement.textContent = errorMessage;
    errorElement.classList.add('popup__input-error_visible');
    errorElement.textContent = 'Максимальная сумма: ' + result.maxCredit.toLocaleString()
}
//функция вывода удаления информации об ошибках
const hidleInputError = (formElement, inputElement) => {
    const errorElement = formElement.querySelector(`.${inputElement.id}-error`);
    inputElement.classList.remove('popup__input-errorSa')
    errorElement.classList.remove('popup__input-error_visible');
    errorElement.textContent = '';
    
}

//вызов функций по блокировании кнопки расчета и проверки на валидность формы
const setEventListener = (formElement) => {
    const inputList = Array.from(formElement.querySelectorAll('.paramentsForm__sum_razryd'));
    inputList.forEach((inputElement) => {
        inputElement.addEventListener('input', ()=>{
            isValid(formElement, inputElement)
            toggleButtonState(inputList, btn)
        })
    })
}

//функция по поиску формы
export const enableValidation = () => {
    const formList = Array.from(document.querySelectorAll('.paramentsForm'));
    formList.forEach((formElement) => {
        setEventListener(formElement)
    })
}

const hasInvalidInput = (inputList) => {
    const result = CarCredit.data.find(obj => obj.name === celsProgram.value)
    return inputList.some((inputElement) => {
        let sum = parseFloat(inputElement.value.replace(/ /g, ''))
        return sum<minCarCr || sum>result.maxCredit
    })
}
//функция по активации и деактивации кнопки
const toggleButtonState = (inputList, btn) => {
    if (hasInvalidInput(inputList)){
        btn.classList.add('paramentsForm__btn_inactive')
    } else {
        btn.classList.remove('paramentsForm__btn_inactive')
    }
}

//вызов валидации формы
enableValidation()

document.getElementById("carKZClose").addEventListener("click", () => {
    document.getElementById("carKZModal").style.display = "none";
});
