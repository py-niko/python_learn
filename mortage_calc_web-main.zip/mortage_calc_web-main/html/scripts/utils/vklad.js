export const period = [//сроки вкладов
        {
            period: [30, 31, 61, 93, 180, 185, 186, 187, 279, 280, 360, 365, 370, 372, 390, 465, 625, 720, 730, 740, 837, 1080, 1095, 1110, 1170,],
        },
    ]
    
export const vklad = {
    data: [
        {
            name: 'Выберите вклад',
        },

        {
        name: 'ВКЛАД НАРОДНЫЙ', //название вкладов
        about: 'доп. пополнение с 94 дня', //информация о вкладу
        minSumVklad: 10000, // минимальная сумма вклада народный
        periodOneMin: 1, // минимальный 1 период
        periodOneMax: 30, // максимальный 1 период
        procentOne: 0.1600, // процент по 1 периоду
        
        periodTwoMin: 31, // минимальный 2 период
        periodTwoMax: 61, // максимальный 2 период
        procentTwo: 0.1180, // процент по 2 периоду
        
        periodThreeMin: 62, // минимальный 3 период
        periodThreeMax: 93, // максимальный 3 период
        procentThree: 0.1115, // процент по 3 периоду
        
        periodFourMin: 94, // минимальный 4 период
        periodFourMax: 186, // максимальный 4 период
        procentFour: 0.0925, // процент по 4 периоду
        
        periodFiveMin: 187, // минимальный 5 период
        periodFiveMax: 279, // максимальный 5 период
        procentFive: 0.0950, // процент по 5 периоду

        periodSixMin: 280, // минимальный 6 период
        periodSixMax: 837, // максимальный 6 период
        procentSix: 0.1025, // процент по 6 периоду
        
        periodPay:31, // период выплат процентов
        popolnenie: true, //пополнение (true=возможно, false=нельзя)
        capitalyti: false, //капитализация (true=возможно, false=нельзя)
        prolongate: false, //пролонгация (true=возможно, false=нельзя)
        
    },
        {
        name: 'Правильный выбор', //название вкладов1
        about: 'доп. пополнение с 94 дня', //информация о вкладу
        minSumVklad: 1000, // минимальная сумма вклада!
        periodOneMin: 1, // минимальный 1 период
        periodOneMax: 93, // максимальный 1 период
        procentOne: 0.1200, // процент по 1 периоду
        
        periodTwoMin: 94, // минимальный 2 период
        periodTwoMax: 186, // максимальный 2 период
        procentTwo: 0.09750, // процент по 2 периоду
        
        periodThreeMin: 187, // минимальный 3 период
        periodThreeMax: 279, // максимальный 3 период
        procentThree: 0.09800, // процент по 3 периоду
        
        periodFourMin: 280, // минимальный 4 период
        periodFourMax: 837, // максимальный 4 период
        procentFour: 0.1035, // процент по 4 периоду_1075
        
        periodFiveMin: 0, // минимальный 5 период
        periodFiveMax: 0, // максимальный 5 период
        procentFive: 0, // процент по 5 периоду 3
        
        periodPay:93, // период выплат процентов
        popolnenie: true, //пополнение (true=возможно, false=нельзя)
        capitalyti: false, //капитализация (true=возможно, false=нельзя)
        prolongate: false, //пролонгация (true=возможно, false=нельзя)
        
    },

        {
        name: 'Привет!', //название вкладов1
        about: 'доп. пополнение с 94 дня', //информация о вкладу
        minSumVklad: 1000, // минимальная сумма вклада
        periodOneMin: 1, // минимальный 1 период
        periodOneMax: 93, // максимальный 1 период
        procentOne: 0.1400, // процент по 1 периоду
        
        periodTwoMin: 94, // минимальный 2 период
        periodTwoMax: 186, // максимальный 2 период
        procentTwo: 0.1200, // процент по 2 периоду
        
        periodThreeMin: 187, // минимальный 3 период
        periodThreeMax: 279, // максимальный 3 период
        procentThree: 0.0950, // процент по 3 периоду
        
        periodFourMin: 280, // минимальный 4 период
        periodFourMax: 837, // максимальный 4 период
        procentFour: 0.1100, // процент по 4 периоду
        
        periodFiveMin: 0, // минимальный 5 период
        periodFiveMax: 0, // максимальный 5 период
        procentFive: 0, // процент по 5 периоду
        
        periodPay:93, // период выплат процентов
        popolnenie: true, //пополнение (true=возможно, false=нельзя)
        capitalyti: false, //капитализация (true=возможно, false=нельзя)
        prolongate: false, //пролонгация (true=возможно, false=нельзя)
        
    },

        {
        name: 'Вместе', //название вкладов1
        about: 'доп. пополнение с 94 дня', //информация о вкладу
        minSumVklad: 1000, // минимальная сумма вклада
        periodOneMin: 1, // минимальный 1 период
        periodOneMax: 93, // максимальный 1 период
        procentOne: 0.1275, // процент по 1 периоду
        
        periodTwoMin: 94, // минимальный 2 период
        periodTwoMax: 186, // максимальный 2 период
        procentTwo: 0.1025, // процент по 2 периоду
        
        periodThreeMin: 187, // минимальный 3 период
        periodThreeMax: 279, // максимальный 3 период
        procentThree: 0.0985, // процент по 3 периоду
        
        periodFourMin: 280, // минимальный 4 период
        periodFourMax: 837, // максимальный 4 период
        procentFour: 0.1100, // процент по 4 периоду
        
        periodFiveMin: 0, // минимальный 5 период
        periodFiveMax: 0, // максимальный 5 период
        procentFive: 0, // процент по 5 периоду
        
        periodPay:93, // период выплат процентов
        popolnenie: true, //пополнение (true=возможно, false=нельзя)
        capitalyti: false, //капитализация (true=возможно, false=нельзя)
        prolongate: false, //пролонгация (true=возможно, false=нельзя)
        
    },

    {
        name: 'Правильный выбор онлайн', //название вкладов
        about: 'доп. пополнение с 94 дня', //информация о вкладу
        minSumVklad: 1000, // минимальная сумма вклада
        periodOneMin: 1, // минимальный 1 период
        periodOneMax: 93, // максимальный 1 период
        procentOne: 0.1250, // процент по 1 периоду
        
        periodTwoMin: 94, // минимальный 2 период
        periodTwoMax: 186, // максимальный 2 период
        procentTwo: 0.0975, // процент по 2 периоду
        
        periodThreeMin: 187, // минимальный 3 период
        periodThreeMax: 279, // максимальный 3 период
        procentThree: 0.0980, // процент по 3 периоду
        
        periodFourMin: 280, // минимальный 4 период
        periodFourMax: 837, // максимальный 4 период
        procentFour: 0.1045, // процент по 4 периоду
        
        periodFiveMin: 0, // минимальный 5 период
        periodFiveMax: 0, // максимальный 5 период
        procentFive: 0, // процент по 5 периоду
        
        periodPay:93, // период выплат процентов
        popolnenie: true, //пополнение (true=возможно, false=нельзя)
        capitalyti: false, //капитализация (true=возможно, false=нельзя)
        prolongate: false, //пролонгация (true=возможно, false=нельзя)
        
    },
    {
        name: 'Онл@йн', //название вкладов
        about: 'доп. пополнение в течение 185 дней с открытия вклада, капитализация: каждые 185 дней', //информация о вкладу
        minSumVklad: 1000, // минимальная сумма вклада
        periodOneMin: 1, // минимальный 1 период
        periodOneMax: 185, // максимальный 1 период
        procentOne: 0.1225, // процент по 1 периоду
        
        periodTwoMin: 186, // минимальный 2 период
        periodTwoMax: 370, // максимальный 2 период
        procentTwo: 0.1085, // процент по 2 периоду
        
        periodThreeMin: 0, // минимальный 3 период
        periodThreeMax: 0, // максимальный 3 период
        procentThree: 0, // процент по 3 периоду
        
        periodFourMin: 0, // минимальный 4 период
        periodFourMax: 0, // максимальный 4 период
        procentFour: 0, // процент по 4 периоду
        
        periodFiveMin: 0, // минимальный 5 период
        periodFiveMax: 0, // максимальный 5 период
        procentFive: 0, // процент по 5 периоду
        
        periodPay:185, // период выплат процентов
        popolnenie: true, //пополнение (true=возможно, false=нельзя)
        capitalyti: true, //капитализация (true=возможно, false=нельзя)
        prolongate: false, //пролонгация (true=возможно, false=нельзя)
        
    },
    {
        name: 'Олимп', //название вкладов
        about: 'доп. пополнение в течение 390 дней с открытия вклада, капитализация: каждые 30 дней', //информация о вкладу
        minSumVklad: 3000000, // минимальная сумма вклада
        periodOneMin: 1, // минимальный 1 период
        periodOneMax: 390, // максимальный 1 период
        procentOne: 0.1325, // процент по 1 периоду

        periodTwoMin: 391, // минимальный 2 период
        periodTwoMax: 1170, // максимальный 2 период
        procentTwo: 0.0735, // процент по 2 периоду

        periodThreeMin: 0, // минимальный 3 период
        periodThreeMax: 0, // максимальный 3 период
        procentThree: 0, // процент по 3 периоду

        periodFourMin: 0, // минимальный 4 период
        periodFourMax: 0, // максимальный 4 период
        procentFour: 0, // процент по 4 периоду
        
        periodFiveMin: 0, // минимальный 5 период
        periodFiveMax: 0, // максимальный 5 период
        procentFive: 0, // процент по 5 периоду

        periodPay:30, // период выплат процентов
        popolnenie: true, //пополнение (true=возможно, false=нельзя)
        capitalyti: true, //капитализация (true=возможно, false=нельзя)
        prolongate: false, //пролонгация (true=возможно, false=нельзя)
    },
    // {
    //     name: 'Новая высота', //название вкладов
    //     about: 'доп. пополнение не предусмотрен, капитализация: нет', //информация о вкладу
    //     minSumVklad: 500000, // минимальная сумма вклада
    //     periodOneMin: 1, // минимальный 1 период
    //     periodOneMax: 625, // максимальный 1 период
    //     procentOne: 0.1200, // процент по 1 периоду

    //     periodTwoMin: 0, // минимальный 2 период
    //     periodTwoMax: 0, // максимальный 2 период
    //     procentTwo: 0, // процент по 2 периоду

    //     periodThreeMin: 0, // минимальный 3 период
    //     periodThreeMax: 0, // максимальный 3 период
    //     procentThree: 0, // процент по 3 периоду

    //     periodFourMin: 0, // минимальный 4 период
    //     periodFourMax: 0, // максимальный 4 период
    //     procentFour: 0, // процент по 4 периоду
        
    //     periodFiveMin: 0, // минимальный 5 период
    //     periodFiveMax: 0, // максимальный 5 период
    //     procentFive: 0, // процент по 5 периоду

    //     periodPay:625, // период выплат процентов
    //     popolnenie: false, //пополнение (true=возможно, false=нельзя)
    //     capitalyti: false, //капитализация (true=возможно, false=нельзя)
    //     prolongate: false, //пролонгация (true=возможно, false=нельзя)
    // },
    {
        name: 'Пенсионный+', //название вкладов
        about: 'доп. пополнение от 1000 руб., капитализация: каждые 93 дня', //информация о вкладу
        minSumVklad: 1000, // минимальная сумма вклада
        periodOneMin: 1, // минимальный 1 период
        periodOneMax: 465, // максимальный 1 период
        procentOne: 0.1050, // процент по 1 периоду

        periodTwoMin: 0, // минимальный 2 период
        periodTwoMax: 0, // максимальный 2 период
        procentTwo: 0, // процент по 2 периоду

        periodThreeMin: 0, // минимальный 3 период
        periodThreeMax: 0, // максимальный 3 период
        procentThree: 0, // процент по 3 периоду

        periodFourMin: 0, // минимальный 4 период
        periodFourMax: 0, // максимальный 4 период
        procentFour: 0, // процент по 4 периоду
        
        periodFiveMin: 0, // минимальный 5 период
        periodFiveMax: 0, // максимальный 5 период
        procentFive: 0, // процент по 5 периоду

        periodPay:93, // период выплат процентов
        popolnenie: true, //пополнение (true=возможно, false=нельзя)
        capitalyti: true, //капитализация (true=возможно, false=нельзя)
        prolongate: true, //пролонгация (true=возможно, false=нельзя)
    },
    {
        name: 'Новый горизонт', //название вкладов
        about: 'доп. пополнение с 181 дня со дня открытия вклада, капитализация: каждые 180 дней', //информация о вкладу
        minSumVklad: 10000, // минимальная сумма вклада
        periodOneMin: 1, // минимальный 1 период
        periodOneMax: 180, // максимальный 1 период
        procentOne: 0.1150, // процент по 1 периоду

        periodTwoMin: 181, // минимальный 2 период
        periodTwoMax: 360, // максимальный 2 период
        procentTwo: 0.0900, // процент по 2 периоду

        periodThreeMin: 361, // минимальный 3 период
        periodThreeMax: 720, // максимальный 3 период
        procentThree: 0.0945, // процент по 3 периоду

        periodFourMin: 721, // минимальный 4 период
        periodFourMax: 1080, // максимальный 4 период
        procentFour: 0.0930, // процент по 4 периоду
        
        periodFiveMin: 0, // минимальный 5 период
        periodFiveMax: 0, // максимальный 5 период
        procentFive: 0, // процент по 5 периоду

        periodPay:180, // период выплат процентов
        popolnenie: true, //пополнение (true=возможно, false=нельзя)
        capitalyti: false, //капитализация (true=возможно, false=нельзя)
        prolongate: false, //пролонгация (true=возможно, false=нельзя)
    },
    // {
    //     name: 'Постоянный доход', //название вкладов
    //     about: 'доп. пополнение в течение 370 дней со дня открытия вклада, капитализация: каждые 30 дней', //информация о вкладу
    //     minSumVklad: 5000, // минимальная сумма вклада
    //     periodOneMin: 1, // минимальный 1 период
    //     periodOneMax: 370, // максимальный 1 период
    //     procentOne: 0.115, // процент по 1 периоду

    //     periodTwoMin: 371, // минимальный 2 период
    //     periodTwoMax: 740, // максимальный 2 период
    //     procentTwo: 0.0785, // процент по 2 периоду

    //     periodThreeMin: 741, // минимальный 3 период
    //     periodThreeMax: 1110, // максимальный 3 период
    //     procentThree: 0.0755, // процент по 3 периоду

    //     periodFourMin: 0, // минимальный 4 период
    //     periodFourMax: 0, // максимальный 4 период
    //     procentFour: 0, // процент по 4 периоду

    //     periodFiveMin: 0, // минимальный 5 период
    //     periodFiveMax: 0, // максимальный 5 период
    //     procentFive: 0, // процент по 5 периоду

    //     periodPay:31, // период выплат процентов !!!!!ВНИМАНИЕ ПЕРИОД УВЕЛИЧЕН НА 1 день ПРИ ИЗМЕНИИ СТАВКИ ИЛИ СРОКОВ НЕОБХОДИМО ПРОВЕСТИ ПРОВЕРКУ КОРРЕКТНОСТИ ДАННЫХ 
    //     popolnenie: true, //пополнение (true=возможно, false=нельзя)
    //     capitalyti: false, //капитализация (true=возможно, false=нельзя)
    //     prolongate: false, //пролонгация (true=возможно, false=нельзя)
    // },
    {
        name: 'Эверест', //название вкладов
        about: 'доп. пополнение с 181 дня со дня открытия вклада, капитализация: каждые 180 дней', //информация о вкладу новая
        minSumVklad: 10000, // минимальная сумма вклада
        periodOneMin: 1, // минимальный 1 период
        periodOneMax: 180, // максимальный 1 период
        procentOne: 0.1350, // процент по 1 периоду

        periodTwoMin: 181, // минимальный 2 период
        periodTwoMax: 360, // максимальный 2 период
        procentTwo: 0.1300, // процент по 2 периоду

        periodThreeMin: 361, // минимальный 3 период
        periodThreeMax: 720, // максимальный 3 период
        procentThree: 0.1230, // процент по 3 периоду

        periodFourMin: 721, // минимальный 4 период
        periodFourMax: 1080, // максимальный 4 период
        procentFour: 0.0850, // процент по 4 периоду
        
        periodFiveMin: 0, // минимальный 5 период
        periodFiveMax: 0, // максимальный 5 период
        procentFive: 0, // процент по 5 периоду

        periodPay:180, // период выплат процентов
        popolnenie: true, //пополнение (true=возможно, false=нельзя)
        capitalyti: false, //капитализация (true=возможно, false=нельзя)
        prolongate: false, //пролонгация (true=возможно, false=нельзя)
    },
    {
        name: 'Солнышко', //название вкладов
        about: 'доп. пополнение в течение всего срока, капитализация: каждые 60 дней', //информация о вкладу
        minSumVklad: 1000, // минимальная сумма вклада
        periodOneMin: 1, // минимальный 1 период
        periodOneMax: 360, // максимальный 1 период
        procentOne: 0.0975, // процент по 1 периоду

        periodTwoMin: 361, // минимальный 2 период
        periodTwoMax: 720, // максимальный 2 период
        procentTwo: 0.06, // процент по 2 периоду

        periodThreeMin: 721, // минимальный 3 период
        periodThreeMax: 1080, // максимальный 3 период
        procentThree: 0.055, // процент по 3 периоду

        periodFourMin: 0, // минимальный 4 период
        periodFourMax: 0, // максимальный 4 период
        procentFour: 0, // процент по 4 периоду

        periodFiveMin: 0, // минимальный 5 период
        periodFiveMax: 0, // максимальный 5 период
        procentFive: 0, // процент по 5 периоду

        periodPay:60, // период выплат процентов
        popolnenie: true, //пополнение (true=возможно, false=нельзя)
        capitalyti: true, //капитализация (true=возможно, false=нельзя)
        prolongate: true, //пролонгация (true=возможно, false=нельзя)
    },
    {
        name: 'Депозитный', //название вкладов
        about: 'доп. пополнение не предусмотрен, капитализация: нет', //информация о вкладу
        minSumVklad: 1000, // минимальная сумма вклада
        periodOneMin: 1, // минимальный 1 период
        periodOneMax: 31, // максимальный 1 период
        procentOne: 0.055, // процент по 1 периоду

        periodTwoMin: 0, // минимальный 2 период
        periodTwoMax: 0, // максимальный 2 период
        procentTwo: 0, // процент по 2 периоду

        periodThreeMin: 0, // минимальный 3 период
        periodThreeMax: 0, // максимальный 3 период
        procentThree: 0, // процент по 3 периоду

        periodFourMin: 0, // минимальный 4 период
        periodFourMax: 0, // максимальный 4 период
        procentFour: 0, // процент по 4 периоду

        periodFiveMin: 0, // минимальный 5 период
        periodFiveMax: 0, // максимальный 5 период
        procentFive: 0, // процент по 5 периоду

        periodPay:31, // период выплат процентов
        popolnenie: false, //пополнение (true=возможно, false=нельзя)
        capitalyti: false, //капитализация (true=возможно, false=нельзя)
        prolongate: true, //пролонгация (true=возможно, false=нельзя)
    },
    {
        name: 'ПИК', //название вкладов
        about: 'доп. пополнение не предусмотрен, капитализация: нет', //информация о вкладу
        minSumVklad: 5000000, // минимальная сумма вклада
        periodOneMin: 1, // минимальный 1 период
        periodOneMax: 365, // максимальный 1 период
        procentOne: 0.1350, // процент по 1 периоду

        periodTwoMin: 366, // минимальный 2 период
        periodTwoMax: 730, // максимальный 2 период
        procentTwo: 0.1155, // процент по 2 периоду

        periodThreeMin: 731, // минимальный 3 период
        periodThreeMax: 1095, // максимальный 3 период
        procentThree: 0.0795, // процент по 3 периоду

        periodFourMin: 0, // минимальный 4 период
        periodFourMax: 0, // максимальный 4 период
        procentFour: 0, // процент по 4 периоду

        periodFiveMin: 0, // минимальный 5 период
        periodFiveMax: 0, // максимальный 5 период
        procentFive: 0, // процент по 5 периоду

        periodPay:365, // период выплат процентов
        popolnenie: false, //пополнение (true=возможно, false=нельзя)
        capitalyti: false, //капитализация (true=возможно, false=нельзя)
        prolongate: false, //пролонгация (true=возможно, false=нельзя)
        },
    {
        name: 'ЭКОВЛАД', //название вкладов
        about: 'доп. пополнение не предусмотрен, капитализация: нет', //информация о вкладу
        minSumVklad: 1000, // минимальная сумма вклада
        periodOneMin: 1, // минимальный 1 период
        periodOneMax: 185, // максимальный 1 период
        procentOne: 0.1125, // процент по 1 периоду
        
        periodTwoMin: 186, // минимальный 2 период
        periodTwoMax: 370, // максимальный 2 период
        procentTwo: 0.0975, // процент по 2 периоду
    
        periodThreeMin: 0, // минимальный 3 период
        periodThreeMax: 0, // максимальный 3 период
        procentThree: 0, // процент по 3 периоду
    
        periodFourMin: 0, // минимальный 4 период
        periodFourMax: 0, // максимальный 4 период
        procentFour: 0, // процент по 4 периоду

        periodFiveMin: 0, // минимальный 5 период
        periodFiveMax: 0, // максимальный 5 период
        procentFive: 0, // процент по 5 периоду
        
        periodPay:185, // период выплат процентов
        popolnenie: true, //пополнение (true=возможно, false=нельзя)
        capitalyti: true, //капитализация (true=возможно, false=нельзя)
        prolongate: true, //пролонгация (true=возможно, false=нельзя)
        },
        
    {
        name: 'ЭКОВЛАД ОНЛАЙН', //название вкладов
        about: 'доп. пополнение не предусмотрен, капитализация: нет', //информация о вкладу
        minSumVklad: 1000, // минимальная сумма вклада
        periodOneMin: 1, // минимальный 1 период
        periodOneMax: 185, // максимальный 1 период
        procentOne: 0.1150, // процент по 1 периоду
        
        periodTwoMin: 186, // минимальный 2 период
        periodTwoMax: 370, // максимальный 2 период
        procentTwo: 0.1050, // процент по 2 периоду
    
        periodThreeMin: 0, // минимальный 3 период
        periodThreeMax: 0, // максимальный 3 период
        procentThree: 0, // процент по 3 периоду
    
        periodFourMin: 0, // минимальный 4 период
        periodFourMax: 0, // максимальный 4 период
        procentFour: 0, // процент по 4 периоду

        periodFiveMin: 0, // минимальный 5 период
        periodFiveMax: 0, // максимальный 5 период
        procentFive: 0, // процент по 5 периоду
        
        periodPay:185, // период выплат процентов
        popolnenie: true, //пополнение (true=возможно, false=нельзя)
        capitalyti: true, //капитализация (true=возможно, false=нельзя)
        prolongate: true, //пролонгация (true=возможно, false=нельзя)
        },  
    
    {
        name: 'Зелёный капитал', //название вкладов
        about: 'доп. пополнение от 1000 руб., капитализация: каждые 93 дня', //информация о вкладу
        minSumVklad: 1000, // минимальная сумма вклада
        periodOneMin: 1, // минимальный 1 период
        periodOneMax: 93, // максимальный 1 период
        procentOne: 0.1325, // процент по 1 периоду
            
        periodTwoMin: 94, // минимальный 2 период
        periodTwoMax: 186, // максимальный 2 период
        procentTwo: 0.1150, // процент по 2 периоду1
        
        periodThreeMin: 187, // минимальный 3 период
        periodThreeMax: 279, // максимальный 3 период
        procentThree: 0.09500, // процент по 3 периоду
        
        periodFourMin: 280, // минимальный 4 период
        periodFourMax: 372, // максимальный 4 период
        procentFour: 0.0900, // процент по 4 периоду

        periodFiveMin: 373, // минимальный 5 период
        periodFiveMax: 465, // максимальный 5 период
        procentFive: 0.0800, // процент по 5 периоду
            
        periodPay:93, // период выплат процентов
        popolnenie: true, //пополнение (true=возможно, false=нельзя)
        capitalyti: true, //капитализация (true=возможно, false=нельзя)
        prolongate: true, //пролонгация (true=возможно, false=нельзя)
        },     
 
],
}