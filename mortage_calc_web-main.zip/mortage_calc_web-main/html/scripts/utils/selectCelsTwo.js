import { creditProduct } from "./constance.js";
import { paramentGroup } from "./constant.js";
import { addAtribute } from "./addAtribute.js"
import { resetPayment } from "./resetPayment.js"
import { isValidSelect } from "./isValidSelect.js"

//функция выбора 2 селекта с установкой атрибутов, очитски форм и валидации
export function selectCelsTwo () {
    let selectGroup = creditProduct.find(function(item){ //поиск списка и запись их в функцию в переменную item
        return item.name === this.value //вернуть из этого списка name и записать в value
    }, this)
    paramentGroup.innerHTML=''
    selectGroup.groups.forEach(function(item){ //произвести перебор данного списка
    let option = document.createElement('option'); //создаем элемент выпадающего списка
    option.text=item 
    option.value=item
    paramentGroup.appendChild(option) //в этот список загружаем весь список item с именем name
    })
    addAtribute() //вызов функций
    resetPayment()
    isValidSelect()

}
