import { initialCredit, creditProducts } from "./credit.js";

const REFINANCE_PATTERN = /рефинанс/i;

const TERM_RATE_PERIODS = [
  { min: 6, max: 12, key: "procentMainOne", label: "6-12 мес." },
  { min: 13, max: 24, key: "procentMainTwo", label: "13-24 мес." },
  { min: 25, max: 36, key: "procentMainThree", label: "25-36 мес." },
  { min: 37, max: 48, key: "procentMainFour", label: "37-48 мес." },
  { min: 49, max: 60, key: "procentMainFive", label: "49-60 мес." },
  { min: 61, max: 84, key: "procentMainSix", label: "61-84 мес." },
  { min: 85, max: 120, key: "procentMainSeven", label: "85-120 мес." },
];

export const refinanceCreditProducts = creditProducts.filter(function (product) {
  return REFINANCE_PATTERN.test(product.program);
});

function unique(items) {
  return Array.from(new Set(items));
}

export function getRefinanceCategories() {
  const orderedCategories = initialCredit
    .map(function (item) {
      return item.categories;
    })
    .filter(function (category) {
      return refinanceCreditProducts.some(function (product) {
        return product.categories === category;
      });
    });

  return unique(orderedCategories);
}

export function getRefinanceClasses(category) {
  const sourceCategory = initialCredit.find(function (item) {
    return item.categories === category;
  });

  const classes = sourceCategory ? sourceCategory.classCategories : [];

  return classes.filter(function (classCategory) {
    return refinanceCreditProducts.some(function (product) {
      return product.categories === category && product.classCategories === classCategory;
    });
  });
}

export function getRefinancePrograms(category, classCategory) {
  return unique(refinanceCreditProducts
    .filter(function (product) {
      return product.categories === category && product.classCategories === classCategory;
    })
    .map(function (product) {
      return product.program;
    }));
}

export function getRefinanceProduct(category, classCategory, program) {
  return refinanceCreditProducts.find(function (product) {
    return product.categories === category && product.classCategories === classCategory && product.program === program;
  }) || null;
}

export function getRatePeriod(termMonths) {
  return TERM_RATE_PERIODS.find(function (period) {
    return termMonths >= period.min && termMonths <= period.max;
  }) || null;
}

export function getBaseRate(product, termMonths) {
  const period = getRatePeriod(termMonths);

  if (!product || !period) {
    return null;
  }

  const rate = Number(product[period.key]) || 0;

  if (rate <= 0) {
    return null;
  }

  return {
    rate: rate,
    period: period,
  };
}

export function getFinalRate(product, termMonths, options) {
  const baseRate = getBaseRate(product, termMonths);

  if (!baseRate) {
    return null;
  }

  const electronicDiscount = options && options.electronic ? Number(product.procentDownSt) || 0 : 0;
  const guarantorDiscount = options && options.guarantor ? Number(product.procentDownGuarantor) || 0 : 0;
  const rate = Math.max(baseRate.rate - electronicDiscount - guarantorDiscount, 0);

  return {
    rate: rate,
    baseRate: baseRate.rate,
    period: baseRate.period,
    electronicDiscount: electronicDiscount,
    guarantorDiscount: guarantorDiscount,
  };
}

export function getMinCredit(product, options) {
  if (!product) {
    return 0;
  }

  if (options && options.electronic && Number(product.minCreditStr) > 0) {
    return Number(product.minCreditStr);
  }

  return Number(product.minCredit) || 0;
}

export function getAvailableRatePeriods(product) {
  if (!product) {
    return [];
  }

  return TERM_RATE_PERIODS.filter(function (period) {
    return Number(product[period.key]) > 0;
  }).map(function (period) {
    return {
      label: period.label,
      rate: Number(product[period.key]),
    };
  });
}
