export function formatNumberToRazryd(value) {
    const rawValue = String(value || '').replace(/\s/g, '');
    const decimalSeparator = rawValue.includes(',') && !rawValue.includes('.') ? ',' : '.';
    const cleanValue = rawValue
        .replace(',', '.')
        .replace(/[^0-9.]/g, '');
    const hasDecimalPart = cleanValue.includes('.');
    const parts = cleanValue.split('.');
    const decimalPart = parts.slice(1).join('');
    let integerPart = parts[0] || '';

    integerPart = integerPart.replace(/^0+(?=\d)/, '');

    const formattedInteger = integerPart.replace(/\B(?=(\d{3})+(?!\d))/g, ' ');

    if (hasDecimalPart) {
        return `${formattedInteger || '0'}${decimalSeparator}${decimalPart}`;
    }

    return formattedInteger;
}

// Функция по разбиению числа на разряды.
export function parserNumberToRazryd(input) {
    input.value = formatNumberToRazryd(input.value);
}
