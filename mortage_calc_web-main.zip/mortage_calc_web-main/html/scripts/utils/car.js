export const CarCredit = {
    data: [
    {
            name: 'Выберите продукт',
    },
    {
        name: 'На покупку нового автомобиля (автосалон)', //название вкладов
        procent:0.1910,
        procentOtkazKasko:0.000,
        procentDownZP:0.002,
        procentDownKI:0.001,
        procentDownSotrudnik:0.020,
        kZ1:0, //процент по КЗ 1
        kZ2:0.001, //процент по КЗ 2
        kZ3:0.0015, //процент по КЗ 3
        timeOne:0, //процент по сроку кредита 1 пункт
        timeSecond:0.0010, //процент по сроку кредита 2 пункт
        timeTherty:0.0015, //процент по сроку кредита 3 пункт
        minAge: 12,
        maxAge:84,
        minCredit: 100000,
        maxCredit: 5000000, //максимальная сумма кредита
    },
    {
        name: 'На покупку автомобиля с пробегом (автосалон)', //название вкладов
        procent:0.1950,
        procentOtkazKasko:0.000,
        procentDownZP:0.002,
        procentDownKI:0.001,
        procentDownSotrudnik:0.020,
        kZ1:0, //процент по КЗ 1
        kZ2:0.001, //процент по КЗ 2
        kZ3:0.0015, //процент по КЗ 3
        timeOne:0, //процент по сроку кредита 1 пункт
        timeSecond:0.0010, //процент по сроку кредита 2 пункт
        timeTherty:0.0015, //процент по сроку кредита 3 пункт
        minAge: 12,
        maxAge:84,
        minCredit: 100000,
        maxCredit: 5000000, //максимальная сумма кредита
    },
    {
        name: 'На покупку автомобиля  (кредит наличными)', //название вкладов
        procent:0.1970,
        procentOtkazKasko:0.000,
        procentDownZP:0.0020,
        procentDownKI:0.0010,
        procentDownSotrudnik:0.02,
        kZ1:0, //процент по КЗ 1
        kZ2:0.000, //процент по КЗ 2
        kZ3:0.0000, //процент по КЗ 3
        timeOne:0, //процент по сроку кредита 1 пункт
        timeSecond:0.0010, //процент по сроку кредита 2 пункт
        timeTherty:0.0015, //процент по сроку кредита 3 пункт
        minAge: 12,
        maxAge:84,
        minCredit: 100000,
        maxCredit: 5000000, //максимальная сумма кредита
    },
    {
        name: 'Рефинансирование автокредита + НН', //название вкладов
        procent:0.1775,
        procentOtkazKasko:0.000,
        procentDownZP:0.0020,
        procentDownKI:0.0010,
        procentDownSotrudnik:0.01,
        kZ1:0, //процент по КЗ 1
        kZ2:0.000, //процент по КЗ 2
        kZ3:0.0000, //процент по КЗ 3
        timeOne:0, //процент по сроку кредита 1 пункт
        timeSecond:0.0010, //процент по сроку кредита 2 пункт
        timeTherty:0.0015, //процент по сроку кредита 3 пункт
        minAge: 12,
        maxAge:84,
        minCredit: 100000,
        maxCredit: 5000000, //максимальная сумма кредит
    },
],
}