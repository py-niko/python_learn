import { paramentGroups, errorGroup } from './constant.js'
//функция вывода ифнормации что невыбрана группа для ИПОТЕКА
export function isValidSelect() {
    if(paramentGroups.value === 'Выберите группу') { //проверка выбрана ли группа для расчёта 
        errorGroup.classList.add('popup__input-error_visible');
        errorGroup.textContent = 'Выберите группу'
    }
}