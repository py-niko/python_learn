import { 
    celsProgram,
    credictProduct,
    firstOne,
    twoSecond,
    threeSecond,
    guarantorSt,
    zarplataSt,
    kiSt,
    electronSt,
    noRefSt,
    noStrahovkaSt,
    citySt
} from "./constant.js"

import { creditProduct } from "./constance.js"
import { creditProducts } from "./credit.js"
import { CarCredit } from "./car.js"
import { updateDateCredit } from "./resulting.js"


/* ------------------------- ИПОТЕКА ----------------------------- */

export function addBtnZarplata(evt) {
    evt.preventDefault()
    const result = creditProduct.find(obj =>
        obj.program === celsProgram.value &&
        obj.name === credictProduct.value
    )
    zarplataSt.value = (result?.procentDownZP || 0) * 100
}

export function addBtnKi(evt) {
    evt.preventDefault()
    const result = creditProduct.find(obj =>
        obj.program === celsProgram.value &&
        obj.name === credictProduct.value
    )
    kiSt.value = (result?.procentDownKI || 0) * 100
}

export function addBtnElectrons(evt) {
    evt.preventDefault()
    const result = creditProduct.find(obj =>
        obj.program === celsProgram.value &&
        obj.name === credictProduct.value
    )
    electronSt.value = (result?.procentDownElectrons || 0) * 100
}

export function addBtnNoRef(evt) {
    evt.preventDefault()
    const result = creditProduct.find(obj =>
        obj.program === celsProgram.value &&
        obj.name === credictProduct.value
    )
    noRefSt.value = (result?.procentDownNoRef || 0) * 100
}

export function addBtnStrahovka(evt) {
    evt.preventDefault()
    const result = creditProduct.find(obj =>
        obj.program === celsProgram.value &&
        obj.name === credictProduct.value
    )
    noStrahovkaSt.value = (result?.procentUP || 0) * 100
}

/* Кнопки удаления */
export function deleteBtnZarplata(e){ e.preventDefault(); zarplataSt.value = 0 }
export function deleteBtnKi(e){ e.preventDefault(); kiSt.value = 0 }
export function deleteBtnElectrons(e){ e.preventDefault(); electronSt.value = 0 }
export function deleteBtnNoRef(e){ e.preventDefault(); noRefSt.value = 0 }
export function deleteBtnStrahovka(e){ e.preventDefault(); noStrahovkaSt.value = 0 }


/* ------------------- ИПОТЕКА: Скидка по городу ------------------ */

export function addBtnCity(evt) {
    evt.preventDefault()

    const result = creditProduct.find(obj =>
        obj.program === celsProgram.value &&
        obj.name === credictProduct.value
    )

    if (!result?.procentDownCity) {
        citySt.value = 0
        return
    }

    citySt.value = result.procentDownCity * 100
}

export function deleteBtnCity(evt) {
    evt.preventDefault()
    citySt.value = 0
}


/* ------------------------- КРЕДИТЫ ----------------------------- */

export function addBtnStrahovkaCredit(evt) {
    evt.preventDefault()
    const result = creditProducts.find(obj =>
        obj.categories === firstOne.value &&
        obj.classCategories === twoSecond.value &&
        obj.program === threeSecond.value
    )

    noStrahovkaSt.value = (result?.procentDownSt || 0) * 100
    updateDateCredit()
}

export function deleteBtnStrahovkaCredit(evt) {
    evt.preventDefault()
    noStrahovkaSt.value = 0
    updateDateCredit()
}

// Поручитель
export function addBtnGuarantorCredit(evt) {
    evt.preventDefault()
    const result = creditProducts.find(obj =>
        obj.categories === firstOne.value &&
        obj.classCategories === twoSecond.value &&
        obj.program === threeSecond.value
    )
    guarantorSt.value = (result?.procentDownGuarantor || 0) * 100
    updateDateCredit()
}

export function deleteBtnGuarantorCredit(evt) {
    evt.preventDefault()
    guarantorSt.value = 0
    updateDateCredit()
}


/* ------------------------- АВТОКРЕДИТ ----------------------------- */

export function addBtnCarZarplata(evt){
    evt.preventDefault()
    const result = CarCredit.data.find(obj => obj.name === celsProgram.value)
    zarplataSt.value = (result?.procentDownZP || 0) * 100
}

export function addBtnCarKi(evt){
    evt.preventDefault()
    const result = CarCredit.data.find(obj => obj.name === celsProgram.value)
    kiSt.value = (result?.procentDownKI || 0) * 100
}

export function addBtnCarElectrons(evt){
    evt.preventDefault()
    const result = CarCredit.data.find(obj => obj.name === celsProgram.value)
    electronSt.value = (result?.procentDownSotrudnik || 0) * 100
}

export function addBtnKASKO(evt){
    evt.preventDefault()
    const result = CarCredit.data.find(obj => obj.name === celsProgram.value)
    noStrahovkaSt.value = (result?.procentOtkazKasko || 0) * 100
}

export function deleteBtnCarZarplata(e){ e.preventDefault(); zarplataSt.value = 0 }
export function deleteBtnCarKi(e){ e.preventDefault(); kiSt.value = 0 }
export function deleteBtnCarElectrons(e){ e.preventDefault(); electronSt.value = 0 }
export function deleteBtnKASKO(e){ e.preventDefault(); noStrahovkaSt.value = 0 }