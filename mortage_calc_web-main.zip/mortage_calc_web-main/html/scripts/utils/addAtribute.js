import { creditProduct } from "./constance.js";
import { celsProgram, credictProduct, sumCredit, costHouse, timeCredit, noStrahovkaSt, firstOne, twoSecond, threeSecond, errorTime, btn, dopCredit, errorGroup, guarantorSt } from "./constant.js"
import { creditProducts } from "./credit.js";
import { CarCredit } from "./car.js";
import { resulting } from "./resulting.js";
import { isValidAgeCredit, isValidAgeIpoteka } from "./formValidator.js"

const errorElement = document.getElementById('error-sumCredit');


/* === Поручитель (аналог noStrahovkaSt) — только геттер === */
export function getGuarantorValue() {
  return guarantorSt ? (Number(guarantorSt.value) || 0) : 0;
}

//функция которая в зависимости от выбранного продукта добавляет атрибуты в сроках/стоимости жилья/кредита, а также удаляет все ограничения (блокировка кнопки расчет и валидации)
export function addAtribute() {
    const result = creditProduct.find(obj => obj.program === celsProgram.value && obj.name === credictProduct.value) //поиск продукта по параметрам из списка 
    timeCredit.setAttribute('min', result.minAge) //установки атрибутов input в возрасте
    timeCredit.setAttribute('max', result.maxAge)
    //timeCredit.value=result.minAge
    sumCredit.setAttribute('min', result.minCredit) //установки атрибутов input в сумме кредита
    sumCredit.value=result.minCredit
    costHouse.setAttribute('min', result.minCredit) //установки атрибутов input в сумме недвижимости
    isValidAgeIpoteka() //вызов функции по проверке возраста
    costHouse.value=result.minCredit  //установка минимальной стоимости кредита из списка
    btn.classList.remove('paramentsForm__btn_inactive') //удаление класса не активной кнопке
    errorElement.classList.remove('popup__input-error_visible'); //удаление класса ошибки
    errorElement.textContent = ''; //удаление информации об ошибках
}

/*функция по валидации кредита на оновываясь на данных вводимых пользователя и атрибутов
Если в селекторе указано "выберите продукт", выдает ошибку (выделяем крассным)
иначе все очищает!
*/
export function isValidSelect() {
    if(threeSecond.value === 'Выберите продукт') { 
        errorGroup.classList.add('popup__input-error_visible');
        errorGroup.textContent = 'Выберите продукт'
        btn.classList.add('paramentsForm__btn_inactive')
    } else {
        errorGroup.classList.remove('popup__input-error_visible');
        errorGroup.textContent = ''
        btn.classList.remove('paramentsForm__btn_inactive')
    }
}

//добавления атрибутов кредитам и проверка на валидность для категории Сотрудник банка вызов функции результата расчёта 
export function addAtributeCredit() {
    const result = creditProducts.find(obj => obj.categories === firstOne.value && obj.classCategories === twoSecond.value && obj.program === threeSecond.value)
    noStrahovkaSt.value=0 //обнуление страховки до 0
    sumCredit.value=result.minCredit //установка минимального значения в input по сумме кредита
    isValidSelect() //вызов функции на проверку 
    dopCredit.checked = false //установка чекбокса на отключено
    costHouse.value=0 //стоимость дома сбрасывается до 0
    costHouse.setAttribute("disabled", true); //установка атрибута неактивно
    timeCredit.setAttribute('min', result.minAge)
    timeCredit.setAttribute('max', result.maxAge)
    //timeCredit.value=result.minAge
    sumCredit.setAttribute('max', result.maxCredit)
    if(firstOne.value === 'Кредит сотруднику Банка'){ //функция если указано что кредит для сотрудника устанавливаем шаг 12 иначе 1
        timeCredit.setAttribute('step', 1)
        isValidAgeCredit()
    }else{
        timeCredit.setAttribute('step', 1)
        isValidAgeCredit()
    }
    // timeCredit.addEventListener('input', () => { //валидация шага для сотрудников так как для сотруника возраст должен быть кратно 12
    //     if(firstOne.value === 'Кредит сотруднику Банка') {
    //         if(timeCredit.value%12){
    //         errorTime.classList.remove('popup__input-error_visible');
    //         errorTime.textContent = 'Кредит может быть выдан только с шагом 12 мес.'
    //         btn.classList.add('paramentsForm__btn_inactiveBtn')
    //         }
    //         else {
    //         timeCredit.classList.remove('popup__input-errorSa')
    //         errorTime.classList.remove('popup__input-error_visible');
    //         btn.classList.remove('paramentsForm__btn_inactiveBtn')
    //         errorTime.textContent=''
    //         }
    //     }
    // })
    resulting() //вызов функции
}

