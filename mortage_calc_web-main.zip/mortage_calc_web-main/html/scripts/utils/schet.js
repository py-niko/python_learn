export const schet = {
    data: [
        {
            name: 'Выберите счёт',
        },
        {
        name: '«Пенсионный - универсальный»', //название вкладов
        minSumSchet: 0, // минимальная сумма вклада
        maxSumSchetOne: 1000000000000000,
        procentOne: 0.0525, // процент по 1 периоду
    },
    {
        name: 'Накопительный счёт', //название вкладов
        minSumSchet: 0, // минимальная сумма вклада
        procentOne: 0.0001, // процент от 0 до 3000 руб.
        maxSumSchetOne: 3000,
        procentTwo: 0.0950, // процент от 3000 до 2 000 000 руб.
        minSumSchetTwo: 3001,
        maxSumSchetTwo: 2000000,
        procentThree: 0.1050, // процент от 2 000 000 руб.   
        minSumSchetThree: 2000001,
        maxSumSchetThree: 1000000000000000,    
    },
    {
        name: 'Номинальный социальный счёт', //название вкладов
        minSumSchet: 0, // минимальная сумма вклада
        maxSumSchetOne: 1000000000000000,
        procentOne: 0.0525, // процент по 1 периоду
    },
],
}