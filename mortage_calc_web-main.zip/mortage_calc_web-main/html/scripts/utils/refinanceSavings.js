export function calculateAnnuity(principal, annualRate, months) {
  if (months <= 0 || principal <= 0) {
    return {
      payment: 0,
      interest: 0,
      total: 0,
    };
  }

  const monthlyRate = annualRate / 12;

  if (monthlyRate <= 0) {
    const payment = principal / months;

    return {
      payment: payment,
      interest: 0,
      total: principal,
    };
  }

  const payment = principal * monthlyRate / (1 - Math.pow(1 + monthlyRate, -months));
  const total = payment * months;

  return {
    payment: payment,
    interest: total - principal,
    total: total,
  };
}

export function calculateAnnuitySchedule(principal, annualRate, months) {
  if (months <= 0 || principal <= 0) {
    return [];
  }

  const monthlyRate = annualRate / 12;
  const annuity = calculateAnnuity(principal, annualRate, months);
  let remainingPrincipal = principal;

  return Array.from({ length: months }, function (_, index) {
    const month = index + 1;
    const debtStart = remainingPrincipal;
    const interestPayment = monthlyRate > 0 ? debtStart * monthlyRate : 0;
    const principalPayment = month === months
      ? debtStart
      : Math.min(annuity.payment - interestPayment, debtStart);
    const payment = interestPayment + principalPayment;

    remainingPrincipal = Math.max(debtStart - principalPayment, 0);

    return {
      month: month,
      debtStart: debtStart,
      payment: payment,
      interestPayment: interestPayment,
      principalPayment: principalPayment,
      debtEnd: remainingPrincipal,
    };
  });
}

export function calculateDifferentiated(principal, annualRate, months) {
  if (months <= 0 || principal <= 0) {
    return {
      firstPayment: 0,
      lastPayment: 0,
      interest: 0,
      total: 0,
    };
  }

  const monthlyRate = annualRate / 12;
  const principalPart = principal / months;
  let remainingPrincipal = principal;
  let interest = 0;
  let firstPayment = 0;
  let lastPayment = 0;

  for (let month = 1; month <= months; month += 1) {
    const interestPart = remainingPrincipal * monthlyRate;
    const payment = principalPart + interestPart;

    if (month === 1) {
      firstPayment = payment;
    }

    lastPayment = payment;
    interest += interestPart;
    remainingPrincipal = Math.max(remainingPrincipal - principalPart, 0);
  }

  return {
    firstPayment: firstPayment,
    lastPayment: lastPayment,
    interest: interest,
    total: principal + interest,
  };
}

export function calculateCurrentCreditInterest(credit) {
  const months = credit.months || credit.monthsLeft || 0;

  if (credit.paymentType === "differentiated") {
    return calculateDifferentiated(credit.principal, credit.annualRate, months).interest;
  }

  return calculateAnnuity(credit.principal, credit.annualRate, months).interest;
}

export function calculateRefinanceSavings(params) {
  const currentInterest = params.credits.reduce(function (total, credit) {
    return total + calculateCurrentCreditInterest(credit);
  }, 0);

  const bankLoan = calculateAnnuity(params.totalCredit, params.bankRate, params.termMonths);
  const rawSavings = currentInterest - bankLoan.interest;

  return {
    currentInterest: currentInterest,
    bankInterest: bankLoan.interest,
    bankMonthlyPayment: bankLoan.payment,
    rawSavings: rawSavings,
    displaySavings: Math.max(rawSavings, 0),
  };
}
