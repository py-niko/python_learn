import { parserNumberToRazryd } from "./parserNumberToRazryd.js";

export const currentDebtLabel = 'Сумма имеющейся ссудной задолженности по кредитам в АО "БАНК ОРЕНБУРГ" (кроме обеспечительных кредитов заемщика в Банке - при наличии)';

export function parseMoneyValue(value) {
  const prepared = String(value || "")
    .replace(/\s/g, "")
    .replace(",", ".")
    .replace(/[^0-9.]/g, "");
  const number = Number(prepared);

  return Number.isFinite(number) ? number : 0;
}

export function formatMoneyValue(value) {
  return Math.round(Number(value) || 0).toLocaleString("ru-RU") + " руб.";
}

function isConsumerProgram(product, category, programs) {
  return product
    && product.categories === category
    && programs.includes(product.program);
}

export function getProductCreditLimit(product, options = {}) {
  if (!product) {
    return 0;
  }

  if (isConsumerProgram(product, "Работающие клиенты", ["На любые цели", "На рефинансирование"])) {
    return 3000000;
  }

  if (isConsumerProgram(product, "Пенсионеры", ["На любые цели", "На рефинансирование"])) {
    return 1000000;
  }

  if (product.categories === "Акция:Новые возможности" && /рефинанс/i.test(product.program || "")) {
    return 2000000;
  }

  const groupValue = Number(options.groupValue);

  if (Number.isFinite(groupValue)) {
    if (groupValue >= 1 && groupValue <= 6 && Number(product.maxCreditGroupOneSix) > 0) {
      return Number(product.maxCreditGroupOneSix);
    }

    if (groupValue >= 7 && groupValue <= 8 && Number(product.maxCreditGroupSevenEight) > 0) {
      return Number(product.maxCreditGroupSevenEight);
    }
  }

  return Number(product.maxCredit) || 0;
}

export function validateCreditLimit(product, params = {}) {
  const creditAmount = Number(params.creditAmount) || 0;
  const currentDebt = Number(params.currentDebt) || 0;
  const limit = getProductCreditLimit(product, params);
  const totalExposure = creditAmount + currentDebt;

  return {
    isValid: !limit || totalExposure <= limit,
    limit: limit,
    creditAmount: creditAmount,
    currentDebt: currentDebt,
    totalExposure: totalExposure,
  };
}

export function getCreditLimitMessage(validation) {
  return "Сумма кредита и текущей задолженности не должна превышать "
    + formatMoneyValue(validation.limit)
    + ". Сейчас: "
    + formatMoneyValue(validation.totalExposure)
    + ".";
}

export function initCurrentDebtControl(options = {}) {
  const checkbox = options.checkbox || document.getElementById(options.checkboxId || "currentDebtToggle");
  const input = options.input || document.getElementById(options.inputId || "currentDebtAmount");
  const error = options.error || document.getElementById(options.errorId || "currentDebtError");
  const onChange = typeof options.onChange === "function" ? options.onChange : function () {};

  function setError(message) {
    if (!error) {
      return;
    }

    error.textContent = message;
    error.classList.toggle("popup__input-error_visible", Boolean(message));
    if (input) {
      input.classList.toggle("popup__input-errorSa", Boolean(message));
    }
  }

  function clearError() {
    setError("");
  }

  function getAmount() {
    if (!checkbox || !checkbox.checked || !input) {
      return 0;
    }

    return parseMoneyValue(input.value);
  }

  function reset() {
    if (checkbox) {
      checkbox.checked = false;
    }

    if (input) {
      input.value = "0";
      input.setAttribute("disabled", true);
    }

    clearError();
  }

  function syncInputState() {
    if (!checkbox || !input) {
      return;
    }

    if (checkbox.checked) {
      input.removeAttribute("disabled");
      if (input.value === "0") {
        input.value = "";
      }
    } else {
      input.value = "0";
      input.setAttribute("disabled", true);
      clearError();
    }

    onChange();
  }

  if (checkbox && input) {
    checkbox.addEventListener("change", syncInputState);
    input.addEventListener("input", function () {
      parserNumberToRazryd(input);
      clearError();
      onChange();
    });
    input.addEventListener("blur", function () {
      parserNumberToRazryd(input);
      if (!input.value) {
        input.value = "0";
      }
      onChange();
    });
    syncInputState();
  }

  return {
    checkbox: checkbox,
    input: input,
    error: error,
    getAmount: getAmount,
    setError: setError,
    clearError: clearError,
    reset: reset,
  };
}
