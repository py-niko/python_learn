import { table } from "./constant.js"
//функция которая вызывает функцию Table2Excel.js и по кнопки ищет таблицу и ее экспортирует в эксель файл
export function tableToExcel(evt) {
    evt.preventDefault()
    var table2excel = new Table2Excel();
    table2excel.export(table);
}