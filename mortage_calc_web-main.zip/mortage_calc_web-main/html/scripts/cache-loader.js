(function () {
  var bootScript = document.currentScript;
  var entry = bootScript && bootScript.dataset ? bootScript.dataset.entry : "";
  var needsExcel = bootScript && bootScript.dataset && bootScript.dataset.excel === "true";
  var version = Date.now().toString(36);
  var baseUrl = new URL("./", window.location.href);

  function withVersion(url) {
    return url + (url.indexOf("?") === -1 ? "?" : "&") + "v=" + version;
  }

  function resolveAsset(path, base) {
    return new URL(path, base || baseUrl).href;
  }

  function appendStylesheet(href) {
    var link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = href;
    document.head.appendChild(link);
  }

  async function loadStyles() {
    var indexCssUrl = resolveAsset("index.css");

    try {
      var response = await fetch(withVersion(indexCssUrl), { cache: "no-store" });

      if (!response.ok) {
        throw new Error("Unable to load index.css");
      }

      var css = await response.text();
      var importPattern = /@import\s+(?:url\()?["']([^"']+)["']\)?\s*;/g;
      var match;
      var hasImports = false;

      while ((match = importPattern.exec(css)) !== null) {
        hasImports = true;
        appendStylesheet(withVersion(resolveAsset(match[1], indexCssUrl)));
      }

      if (!hasImports) {
        appendStylesheet(withVersion(indexCssUrl));
      }
    } catch (error) {
      appendStylesheet(withVersion(indexCssUrl));
    }
  }

  function onDomReady() {
    if (document.readyState !== "loading") {
      return Promise.resolve();
    }

    return new Promise(function (resolve) {
      document.addEventListener("DOMContentLoaded", resolve, { once: true });
    });
  }

  function loadClassicScript(path) {
    return new Promise(function (resolve, reject) {
      var script = document.createElement("script");
      script.src = withVersion(resolveAsset(path));
      script.async = false;
      script.onload = resolve;
      script.onerror = reject;
      document.body.appendChild(script);
    });
  }

  async function collectModuleGraph(moduleUrl, imports) {
    var cleanUrl = moduleUrl.split("#")[0].split("?")[0];

    if (imports[cleanUrl]) {
      return;
    }

    imports[cleanUrl] = withVersion(cleanUrl);

    var response = await fetch(withVersion(cleanUrl), { cache: "no-store" });

    if (!response.ok) {
      throw new Error("Unable to load module: " + cleanUrl);
    }

    var source = await response.text();
    var importPattern = /\bimport\s+(?:[^'"]*?\s+from\s+)?["']([^"']+\.js)["']/g;
    var match;

    while ((match = importPattern.exec(source)) !== null) {
      await collectModuleGraph(resolveAsset(match[1], cleanUrl), imports);
    }
  }

  function appendImportMap(imports) {
    var script = document.createElement("script");
    script.type = "importmap";
    script.textContent = JSON.stringify({ imports: imports });
    document.head.appendChild(script);
  }

  async function loadEntryModule() {
    if (!entry) {
      return;
    }

    var entryUrl = resolveAsset(entry);
    var imports = {};

    try {
      await collectModuleGraph(entryUrl, imports);
      appendImportMap(imports);
    } catch (error) {
      console.warn("Asset cache-busting import map was not created.", error);
    }

    if (needsExcel) {
      await loadClassicScript("table2excel.js");
    }

    await import(withVersion(entryUrl));
  }

  loadStyles();

  onDomReady()
    .then(loadEntryModule)
    .catch(function (error) {
      console.error("Calculator assets failed to load.", error);
    });
}());
