(function () {
  var bootScript = document.currentScript;
  var entry = bootScript && bootScript.dataset ? bootScript.dataset.entry : "";
  var needsExcel = bootScript && bootScript.dataset && bootScript.dataset.excel === "true";
  var version = Date.now().toString(36);
  var baseUrl = new URL("./", window.location.href);
  var revealTimer;

  function showPage() {
    window.clearTimeout(revealTimer);
    window.clearTimeout(window.__assetRevealTimer);
    window.__assetRevealTimer = null;
    document.documentElement.classList.remove("assets-loading");
    document.documentElement.classList.add("assets-ready");
  }

  function holdPageUntilStylesReady() {
    var style = document.getElementById("asset-loading-style");

    if (!style) {
      style = document.createElement("style");
      style.id = "asset-loading-style";
      style.textContent = ".assets-loading body{visibility:hidden}.assets-ready body{visibility:visible}";
      document.head.appendChild(style);
    }

    document.documentElement.classList.remove("no-js");
    document.documentElement.classList.add("assets-loading");
    window.clearTimeout(window.__assetRevealTimer);
    window.__assetRevealTimer = null;
    revealTimer = window.setTimeout(showPage, 5000);
  }

  function withVersion(url) {
    return url + (url.indexOf("?") === -1 ? "?" : "&") + "v=" + version;
  }

  function resolveAsset(path, base) {
    return new URL(path, base || baseUrl).href;
  }

  function appendStylesheet(href) {
    return new Promise(function (resolve) {
      var link = document.createElement("link");
      var loadTimer;
      var done = false;

      function finish() {
        if (done) {
          return;
        }

        done = true;
        window.clearTimeout(loadTimer);
        resolve();
      }

      link.rel = "stylesheet";
      link.href = href;
      link.onload = finish;
      link.onerror = finish;
      loadTimer = window.setTimeout(finish, 5000);
      document.head.appendChild(link);
    });
  }

  async function loadStyles() {
    var indexCssUrl = resolveAsset("index.css");
    var stylesheetLoads = [];

    try {
      var response = await fetch(withVersion(indexCssUrl), { cache: "no-store" });

      if (!response.ok) {
        throw new Error("Unable to load index.css");
      }

      var css = await response.text();
      var importPattern = /@import\s+(?:url\()?["']([^"']+)["']\)?\s*;/g;
      var match;
      var hasImports = false;

      while ((match = importPattern.exec(css)) !== null) {
        hasImports = true;
        stylesheetLoads.push(appendStylesheet(withVersion(resolveAsset(match[1], indexCssUrl))));
      }

      if (!hasImports) {
        stylesheetLoads.push(appendStylesheet(withVersion(indexCssUrl)));
      }
    } catch (error) {
      stylesheetLoads.push(appendStylesheet(withVersion(indexCssUrl)));
    }

    await Promise.all(stylesheetLoads);
  }

  function onDomReady() {
    if (document.readyState !== "loading") {
      return Promise.resolve();
    }

    return new Promise(function (resolve) {
      document.addEventListener("DOMContentLoaded", resolve, { once: true });
    });
  }

  function loadClassicScript(path) {
    return new Promise(function (resolve, reject) {
      var script = document.createElement("script");
      script.src = withVersion(resolveAsset(path));
      script.async = false;
      script.onload = resolve;
      script.onerror = reject;
      document.body.appendChild(script);
    });
  }

  async function collectModuleGraph(moduleUrl, imports) {
    var cleanUrl = moduleUrl.split("#")[0].split("?")[0];

    if (imports[cleanUrl]) {
      return;
    }

    imports[cleanUrl] = withVersion(cleanUrl);

    var response = await fetch(withVersion(cleanUrl), { cache: "no-store" });

    if (!response.ok) {
      throw new Error("Unable to load module: " + cleanUrl);
    }

    var source = await response.text();
    var importPattern = /\bimport\s+(?:[^'"]*?\s+from\s+)?["']([^"']+\.js)["']/g;
    var match;

    while ((match = importPattern.exec(source)) !== null) {
      await collectModuleGraph(resolveAsset(match[1], cleanUrl), imports);
    }
  }

  function appendImportMap(imports) {
    var script = document.createElement("script");
    script.type = "importmap";
    script.textContent = JSON.stringify({ imports: imports });
    document.head.appendChild(script);
  }

  async function loadEntryModule() {
    if (!entry) {
      return;
    }

    var entryUrl = resolveAsset(entry);
    var imports = {};

    try {
      await collectModuleGraph(entryUrl, imports);
      appendImportMap(imports);
    } catch (error) {
      console.warn("Asset cache-busting import map was not created.", error);
    }

    if (needsExcel) {
      await loadClassicScript("table2excel.js");
    }

    await import(withVersion(entryUrl));
  }

  holdPageUntilStylesReady();
  loadStyles()
    .then(showPage)
    .catch(showPage);

  onDomReady()
    .then(loadEntryModule)
    .catch(function (error) {
      console.error("Calculator assets failed to load.", error);
    });
}());
