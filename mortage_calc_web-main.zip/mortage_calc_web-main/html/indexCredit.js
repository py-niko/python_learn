import { initialCredit, creditProducts } from "./scripts/utils/credit.js";
import {firstOne, dopCredit, twoSecond, threeSecond, sumCredit, costHouse, btn, timeCredit, addSubmitStrahovka, deleteSubmitStrahovka, addSubmitGuarantor, deleteSubmitGuarantor, noStrahovkaSt, program,
resultStavka, resultProduct, resultProgramma, monthPayment, pereplata, btnExcel, guarantorSt} from "./scripts/utils/constant.js"
import { parserNumberToRazryd } from './scripts/utils/parserNumberToRazryd.js'
import { fillTable } from "./scripts/utils/fillTable.js";
import { resetPaymentCredit } from "./scripts/utils/resetPayment.js";
import { minCr } from "./scripts/utils/resulting.js";
import { addAtributeCredit, isValidSelect } from "./scripts/utils/addAtribute.js";
import { addBtnStrahovkaCredit,  deleteBtnStrahovkaCredit, addBtnGuarantorCredit, deleteBtnGuarantorCredit} from "./scripts/utils/addStavki.js";
import { isValidAgeCredit } from "./scripts/utils/formValidator.js";
import { tableToExcel } from "./scripts/utils/tableToExcel.js"
import {
    getCreditLimitMessage,
    initCurrentDebtControl,
    parseMoneyValue,
    validateCreditLimit,
} from "./scripts/utils/currentDebtLimit.js";

const currentDebtError = document.getElementById('error-currentDebtCredit')
let currentDebtControl = null

//Кнопки которые вызывают функции клику, изменению 
addSubmitStrahovka.addEventListener('click', addBtnStrahovkaCredit)
deleteSubmitStrahovka.addEventListener('click', deleteBtnStrahovkaCredit)
addSubmitGuarantor.addEventListener('click', addBtnGuarantorCredit);
deleteSubmitGuarantor.addEventListener('click', deleteBtnGuarantorCredit);
threeSecond.addEventListener('change', addAtributeCredit)
firstOne.addEventListener('change', selectProgramOne)
firstOne.addEventListener('change', selectProgramThree)
twoSecond.addEventListener('change', selectProgramTwo)
twoSecond.addEventListener('change', addAtributeCredit)
timeCredit.addEventListener('input', isValidAgeCredit)

//вызов функции разделения чисел на разряды в сумме кредита и в стоимости недвижимости
sumCredit.addEventListener('input', function() {
    parserNumberToRazryd(this)
})

costHouse.addEventListener('input', function() {
    parserNumberToRazryd(this)
})

btn.addEventListener('click', sendForm)
btnExcel.addEventListener('click', tableToExcel)

currentDebtControl = initCurrentDebtControl({
    checkbox: dopCredit,
    input: costHouse,
    error: currentDebtError,
    onChange: function () {
        validateCreditDebtLimit(parseMoneyValue(sumCredit.value))
    },
})
threeSecond.addEventListener('change', function () {
    if (currentDebtControl) currentDebtControl.reset()
})

//функция по перебору списка из credit.js и добавления этих значений в выпадающий список
initialCredit.forEach(function(item){
    const option = document.createElement('option');
    option.text = item.categories
    option.value = item.categories;
    option.innerHTML = item.categories;
    firstOne.appendChild(option)
});

//обнуление повышающей ставки при нажатии второго селектора (изменение программы)
function selectProgramTwo() {
    if(timeCredit.value=='' || timeCredit.value==null){
        
    }
    else {
            isValidAgeCredit()
    }
    noStrahovkaSt.value=0

    if (guarantorSt) guarantorSt.value = 0
    validateCreditDebtLimit(parseMoneyValue(sumCredit.value))
}

//функция позволяющая определить что выбрано из выпадающего списка и установка начальных аттрибутов выбранной программы
function selectProgramOne () {
    let selectCredit = initialCredit.find(function(item) {
        return item.categories === this.value
    }, this)
    twoSecond.innerHTML=''
    noStrahovkaSt.value=0
    if (guarantorSt) guarantorSt.value = 0
    selectCredit.classCategories.forEach(function(item){
    const option = document.createElement('option');
    option.text=item
    option.value=item
    twoSecond.appendChild(option)
    })
    resetPaymentCredit()
    if (currentDebtControl) currentDebtControl.reset()
}
//функция позволяющая определить что выбрано из выпадающего списка и установка начальных аттрибутов выбранной программы
function selectProgramThree() {
    let selectCredit = initialCredit.find(function(item) {
        return item.categories === this.value
    }, this)
    threeSecond.innerHTML=''
    selectCredit.program.forEach(function(item){
    const option = document.createElement('option');
    option.text=item
    option.value=item
    threeSecond.appendChild(option)
    })
    resetPaymentCredit()
    isValidSelect()
    if (currentDebtControl) currentDebtControl.reset()
}

function getSelectedCreditProduct() {
    return creditProducts.find(obj => obj.categories === firstOne.value && obj.classCategories === twoSecond.value && obj.program === threeSecond.value)
}

function getCurrentDebtAmount() {
    return currentDebtControl ? currentDebtControl.getAmount() : 0
}

function validateCreditDebtLimit(creditAmount, showAlert = false) {
    const result = getSelectedCreditProduct()

    if (!result) {
        if (currentDebtControl) currentDebtControl.clearError()
        return true
    }

    const validation = validateCreditLimit(result, {
        creditAmount: creditAmount,
        currentDebt: getCurrentDebtAmount(),
    })

    if (!validation.isValid) {
        const message = getCreditLimitMessage(validation)

        if (currentDebtControl) currentDebtControl.setError(message)
        if (showAlert) alert(message)
        return false
    }

    if (currentDebtControl) currentDebtControl.clearError()
    return true
}

//функция по определению минимальной и максимальной суммы кредита
function sendForm(evt) {
    evt.preventDefault()
    const result = getSelectedCreditProduct()
    let newSumCredit = parseMoneyValue(sumCredit.value)
    const debtValidation = validateCreditLimit(result, {
        creditAmount: newSumCredit,
        currentDebt: getCurrentDebtAmount(),
    })

    if(newSumCredit < minCr || !debtValidation.isValid){
        if (!debtValidation.isValid) {
            const message = getCreditLimitMessage(debtValidation)

            if (currentDebtControl) currentDebtControl.setError(message)
            alert(message)
            return
        }

        alert('Сумма кредита меньше допустимого уровеня\nВаш уровень кредита: ' + newSumCredit + '\nМинимальный уровень: ' + minCr + '\nМаксимальный уровень: ' + debtValidation.limit)
    }
    else{
        //вызов функции если все ок
        viborMonth(newSumCredit)
    }
}

//функция по опредедению повышающего параметра процента основываясь на сроке кредита
function viborMonth(sum) {
    const result = creditProducts.find(obj => obj.categories === firstOne.value && obj.classCategories === twoSecond.value && obj.program === threeSecond.value)
    const noStrahovlaStNum = parseFloat(noStrahovkaSt.value)
    const guarantorNum = parseFloat(guarantorSt?.value) || 0
    const totalDiscountPct = noStrahovlaStNum + guarantorNum  // суммарная скидка, в %
    let procent = 0;
    switch(true) { //в зависимости от введеного месяца получаем повышение ставки и передпчи данных о месячах и повышеющей ставки в следующую функцию
        case timeCredit.value>=6 && timeCredit.value<=12: {
            procent=result.procentMainOne-(totalDiscountPct/100)
            resultingCredit(procent)
        }
        break
        case timeCredit.value>=13 && timeCredit.value<=24: {
            procent=result.procentMainTwo -(totalDiscountPct/100)
            resultingCredit(procent)
        }
        break
        case timeCredit.value>=25 && timeCredit.value<=36: {
            procent=result.procentMainThree -(totalDiscountPct/100)
            resultingCredit(procent)
        }
        break
        case timeCredit.value>=37 && timeCredit.value<=48: {
            procent=result.procentMainFour-(totalDiscountPct/100)
            resultingCredit(procent)
        }
        break
        case timeCredit.value>=49 && timeCredit.value<=60: {
            procent=result.procentMainFive-(totalDiscountPct/100)
            resultingCredit(procent)
        }
        break
        case timeCredit.value>=61 && timeCredit.value<=84: {
            procent=result.procentMainSix-(totalDiscountPct/100)
            resultingCredit(procent)
        }
        break
        case timeCredit.value>=85 && timeCredit.value<=120: {
            procent=result.procentMainSeven-(totalDiscountPct/100)
            resultingCredit(procent)
        }
        break
        default: alert('Ошибка в выборе месяца. Пожалуйста проверьте месяц')
    }
}

//функция по выводу информации об Кредите пользователю
function resultingCredit(procent) {

    let paymentSchedul = [] //пустой массив куда будет записывать данные для таблицы
    let newSumCredit=sumCredit.value //переменная получающее значение от пользовтаеля в формале float
    newSumCredit = parseFloat(newSumCredit.replace(/ /g, ''))

    let remaingPrinciple=parseFloat(newSumCredit)//сумма
    let monthly = parseFloat(timeCredit.value)//месяц
    let monthlyIntersertRate = (procent) / 12 //процент
    let monthlyPayment = remaingPrinciple * monthlyIntersertRate / ( 1 - Math.pow(1 + monthlyIntersertRate, -monthly))
    //функция по обнулнию расчётов для проведения новых расчётов 
    resetPaymentCredit()
        //запись в массив данных по кредиту по месяцам которые потом будут выводиться в таблицу
    for(let i = 1; i<=monthly; i++){
        let insertPayment = parseFloat(remaingPrinciple * monthlyIntersertRate)
        let principalPaymnet = parseFloat(monthlyPayment-insertPayment)
        let monthOpata = parseFloat(insertPayment+principalPaymnet)
        remaingPrinciple -= principalPaymnet
        let principalPaymnetMainCredit = (remaingPrinciple + principalPaymnet)
        paymentSchedul.push({
        month:i,
        principalPaymnet:principalPaymnet.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2}),
        principalPaymnetMainCredit:principalPaymnetMainCredit.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2}),
        insertPayment:insertPayment.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2}),
        monthOpata:monthOpata.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2}),
        remaingPrinciple:Math.abs(remaingPrinciple).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})
    })
    }
    //вывод на страницу данных 
    let addTextMonthPayment = ((remaingPrinciple*monthlyIntersertRate)+(monthlyPayment-remaingPrinciple*monthlyIntersertRate)).toFixed(2)
    //ежемесячный платёж
    let parseAddTextMonthPayment = parseFloat(addTextMonthPayment).toLocaleString()
    monthPayment.textContent += parseAddTextMonthPayment
    //переплата
    let addTextPereplata = parseFloat((addTextMonthPayment*monthly-newSumCredit).toFixed(2)).toLocaleString()
    pereplata.textContent += addTextPereplata
    // процентая ставка
    let addTextResultStavka = (procent * 100).toFixed(2) + '%'
    resultStavka.textContent += addTextResultStavka
    //продукт
    let addTextResultProduct = twoSecond.value
    resultProgramma.textContent += addTextResultProduct
    //программа
    let addTextResultProgramma = firstOne.value
    resultProduct.textContent += addTextResultProgramma
    //цели
    let addTextResultProgram = threeSecond.value
    program.textContent += addTextResultProgram
    //вызов функции по созданию таблицы
    fillTable(paymentSchedul)
}
//валидация формы кредита

//функция по определению сумму кредита с минимальной и максимальной
const isValid = (formElement, inputElement) => {

    let sum = parseMoneyValue(inputElement.value)
    const result = getSelectedCreditProduct()
    const debtValidation = validateCreditLimit(result, {
        creditAmount: sum,
        currentDebt: getCurrentDebtAmount(),
    })

    if (sum<minCr) { //если сумма меньше минимальной вызвать функцию с ошибкой
        showInputErrorMin(formElement, inputElement, inputElement.validationMessage, result)
    }
    else if (!debtValidation.isValid) {
        showInputErrorMax(formElement, inputElement, inputElement.validationMessage, result, debtValidation.limit)
        validateCreditDebtLimit(sum)
    }
    else {//если все ок, вызвать функцию, которая уберет все ошибки.
        hidleInputError(formElement, inputElement)
        validateCreditDebtLimit(sum)
    }

}

//функция вывода ошибки мин. сум. кредита
const showInputErrorMin = (formElement, inputElement, errorMessage, result) => {
    const errorElement = formElement.querySelector(`.${inputElement.id}-error`)
    inputElement.classList.add('popup__input-errorSa')
    errorElement.textContent = errorMessage;
    errorElement.classList.add('popup__input-error_visible');
    errorElement.textContent = 'Минимальная сумма: ' + minCr.toLocaleString()
}
//функция вывода ошибки макс. сум. кредита
const showInputErrorMax = (formElement, inputElement, errorMessage, result, limit) => {
    const errorElement = formElement.querySelector(`.${inputElement.id}-error`)
    inputElement.classList.add('popup__input-errorSa')
    errorElement.textContent = errorMessage;
    errorElement.classList.add('popup__input-error_visible');
    errorElement.textContent = 'Максимальная сумма с учетом текущей задолженности: ' + (limit || result.maxCredit).toLocaleString()
}
//функция вывода удаления информации об ошибках
const hidleInputError = (formElement, inputElement) => {
    const errorElement = formElement.querySelector(`.${inputElement.id}-error`);
    inputElement.classList.remove('popup__input-errorSa')
    errorElement.classList.remove('popup__input-error_visible');
    errorElement.textContent = '';
    
}

//вызов функций по блокировании кнопки расчета и проверки на валидность формы
const setEventListener = (formElement) => {
    const inputList = Array.from(formElement.querySelectorAll('.paramentsForm__sum_razryd'));
    inputList.forEach((inputElement) => {
        inputElement.addEventListener('input', ()=>{
            isValid(formElement, inputElement)
            toggleButtonState(inputList, btn)
        })
    })
}

//функция по поиску формы
export const enableValidation = () => {
    const formList = Array.from(document.querySelectorAll('.paramentsForm'));
    formList.forEach((formElement) => {
        setEventListener(formElement)
    })
}

const hasInvalidInput = (inputList) => {
    const result = getSelectedCreditProduct()
    return inputList.some((inputElement) => {
        let sum = parseMoneyValue(inputElement.value)
        const debtValidation = validateCreditLimit(result, {
            creditAmount: sum,
            currentDebt: getCurrentDebtAmount(),
        })

        return sum<minCr || !debtValidation.isValid
    })
}
//функция по активации и деактивации кнопки
const toggleButtonState = (inputList, btn) => {
    if (hasInvalidInput(inputList)){
        btn.classList.add('paramentsForm__btn_inactive')
    } else {
        btn.classList.remove('paramentsForm__btn_inactive')
    }
}

//вызов валидации формы
enableValidation()
