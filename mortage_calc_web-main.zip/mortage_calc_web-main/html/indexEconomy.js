import {
  getAvailableRatePeriods,
  getFinalRate,
  getMinCredit,
  getRefinanceCategories,
  getRefinanceClasses,
  getRefinanceProduct,
  getRefinancePrograms,
} from "./scripts/utils/refinancePrograms.js";
import {
  calculateAnnuitySchedule,
  calculateRefinanceSavings,
} from "./scripts/utils/refinanceSavings.js";
import { parserNumberToRazryd } from "./scripts/utils/parserNumberToRazryd.js";
import {
  getCreditLimitMessage,
  getProductCreditLimit,
  initCurrentDebtControl,
  validateCreditLimit,
} from "./scripts/utils/currentDebtLimit.js";

const MAX_CREDITS = 12;
const BANK_REFINANCE_MIN_RATIO = 100 / 85;
const DEFAULT_REFINANCE_PROGRAM = "На рефинансирование";

const form = document.getElementById("economyForm");
const categorySelect = document.getElementById("economyCategory");
const classSelect = document.getElementById("economyClass");
const programSelect = document.getElementById("economyProgram");
const termInput = document.getElementById("economyTerm");
const electronicInput = document.getElementById("economyElectronic");
const guarantorInput = document.getElementById("economyGuarantor");
const bankLoansInput = document.getElementById("economyBankLoans");
const extraAmountInput = document.getElementById("economyExtraAmount");
const debtTotalElement = document.getElementById("economyDebtTotal");
const totalCreditElement = document.getElementById("economyTotalCredit");
const currentDebtTotalElement = document.getElementById("economyCurrentDebtTotal");
const selectedRateElement = document.getElementById("economySelectedRate");
const conditionsElement = document.getElementById("economyConditions");
const loansBody = document.getElementById("economyLoansBody");
const loansError = document.getElementById("economyLoansError");
const totalCreditError = document.getElementById("economyTotalCreditError");
const addCreditButton = document.getElementById("economyAddCredit");
const resultElement = document.getElementById("economyResult");
const currentInterestElement = document.getElementById("economyCurrentInterest");
const bankInterestElement = document.getElementById("economyBankInterest");
const paymentElement = document.getElementById("economyPayment");
const analyticElement = document.getElementById("economyAnalytic");
const paymentScheduleTable = document.getElementById("economyPaymentScheduleTable");
const paymentScheduleBody = document.getElementById("economyPaymentScheduleBody");
const exportExcelButton = document.getElementById("economyExportExcel");

const positiveAnalyticText = "Преимущество (экономия) при рефинансировании кредитов и/или получении суммы на неотложные нужды (при наличии) в Банке позволит сэкономить клиенту на переплате процентов по данным кредитам и снизит его долговую нагрузку, что увеличит уровень его платежеспособности в т.ч. при обращении за новым кредитом в Банк.";
const negativeAnalyticText = "Потребность клиента во включении в сумму кредита части на неотложные нужды и/или иные условия нивелирует экономию на процентах при кредитовании в Банке. Однако в полной мере отвечает его потребности в заемных средствах и увеличивает его финансовые возможности. Рекомендуем проверить введенные параметры.";

let creditIndex = 0;
let currentDebtControl = null;

function createOption(value, text) {
  const option = document.createElement("option");
  option.value = value;
  option.textContent = text;
  return option;
}

function fillSelect(selectElement, values, placeholder) {
  selectElement.innerHTML = "";
  selectElement.appendChild(createOption("", placeholder));

  values.forEach(function (value) {
    selectElement.appendChild(createOption(value, value));
  });
}

function parseNumber(value) {
  const prepared = String(value || "")
    .replace(/\s/g, "")
    .replace(",", ".")
    .replace(/[^0-9.]/g, "");

  const number = Number(prepared);

  return Number.isFinite(number) ? number : 0;
}

function parseRate(value) {
  return parseNumber(value) / 100;
}

function formatMoney(value) {
  return Math.round(value).toLocaleString("ru-RU") + " руб.";
}

function formatMoneyPrecise(value) {
  return Number(value).toLocaleString("ru-RU", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }) + " руб.";
}

function formatTableMoney(value) {
  return Number(value).toLocaleString("ru-RU", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

function formatRate(rate) {
  if (!Number.isFinite(rate)) {
    return "0%";
  }

  return (rate * 100).toLocaleString("ru-RU", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }) + "%";
}

function formatNumberInput(input) {
  parserNumberToRazryd(input);
}

function getCurrentProduct() {
  return getRefinanceProduct(categorySelect.value, classSelect.value, programSelect.value);
}

function getCurrentRate() {
  return getFinalRate(getCurrentProduct(), parseInt(termInput.value, 10), {
    electronic: electronicInput.checked,
    guarantor: guarantorInput.checked,
  });
}

function getMonthsToDate(value) {
  if (!value) {
    return 0;
  }

  const endDate = new Date(value + "T00:00:00");
  const now = new Date();

  if (Number.isNaN(endDate.getTime()) || endDate <= now) {
    return 0;
  }

  let months = (endDate.getFullYear() - now.getFullYear()) * 12 + endDate.getMonth() - now.getMonth();

  if (endDate.getDate() > now.getDate()) {
    months += 1;
  }

  return Math.max(months, 1);
}

function getCreditRows() {
  return Array.from(loansBody.querySelectorAll(".economy-credit-row"));
}

function getDebtTotal() {
  return getCreditRows().reduce(function (total, row) {
    return total + parseNumber(row.querySelector(".economy-credit-principal").value);
  }, 0);
}

function getTotalCredit() {
  return getDebtTotal() + parseNumber(extraAmountInput.value);
}

function getCurrentDebtAmount() {
  return currentDebtControl ? currentDebtControl.getAmount() : 0;
}

function renderTotals() {
  const debtTotal = getDebtTotal();
  const totalCredit = getTotalCredit();
  const rate = getCurrentRate();

  debtTotalElement.textContent = formatMoney(debtTotal);
  totalCreditElement.textContent = formatMoney(totalCredit);
  currentDebtTotalElement.textContent = formatMoney(getCurrentDebtAmount());
  selectedRateElement.textContent = rate ? formatRate(rate.rate) : "0%";
}

function renderConditions() {
  const product = getCurrentProduct();
  const termMonths = parseInt(termInput.value, 10);
  const rate = getCurrentRate();

  if (!product) {
    conditionsElement.innerHTML = "<li>Выберите категорию клиента, условия и программу.</li>";
    return;
  }

  const minCredit = getMinCredit(product, { electronic: electronicInput.checked });
  const creditLimit = getProductCreditLimit(product);
  const periods = getAvailableRatePeriods(product)
    .map(function (period) {
      return "<span>" + period.label + ": <strong>" + formatRate(period.rate) + "</strong></span>";
    })
    .join("");

  conditionsElement.innerHTML = [
    "<li>Срок кредитования: от " + product.minAge + " до " + product.maxAge + " мес.</li>",
    "<li>Сумма кредита: от " + formatMoney(minCredit) + " до " + formatMoney(creditLimit) + "</li>",
    '<li class="economy-condition-rates"><strong>Ставки по срокам:</strong><div class="economy-rates-list">' + periods + "</div></li>",
    "<li>Скидка за электронную подачу: " + formatRate(Number(product.procentDownSt) || 0) + "</li>",
    "<li>Скидка за поручителя/созаемщика: " + formatRate(Number(product.procentDownGuarantor) || 0) + "</li>",
    "<li>Ставка по выбранному сроку " + (termMonths || 0) + " мес.: " + (rate ? formatRate(rate.rate) : "не определена") + "</li>",
  ].join("");
}

function validateDebtLimit(showAlert) {
  const product = getCurrentProduct();

  if (!product || !currentDebtControl) {
    if (currentDebtControl) currentDebtControl.clearError();
    return true;
  }

  const validation = validateCreditLimit(product, {
    creditAmount: getTotalCredit(),
    currentDebt: getCurrentDebtAmount(),
  });

  if (!validation.isValid) {
    const message = getCreditLimitMessage(validation);

    currentDebtControl.setError(message);
    if (showAlert) {
      alert(message);
    }
    return false;
  }

  currentDebtControl.clearError();
  return true;
}

function renderPaymentSchedule(schedule) {
  paymentScheduleBody.innerHTML = "";

  if (!schedule.length) {
    const row = paymentScheduleBody.insertRow();
    const cell = row.insertCell();

    cell.colSpan = 6;
    cell.textContent = "График появится после расчета.";
    exportExcelButton.disabled = true;
    return;
  }

  schedule.forEach(function (payment) {
    const row = paymentScheduleBody.insertRow();

    [
      payment.month,
      formatTableMoney(payment.debtStart),
      formatTableMoney(payment.payment),
      formatTableMoney(payment.interestPayment),
      formatTableMoney(payment.principalPayment),
      formatTableMoney(payment.debtEnd),
    ].forEach(function (value) {
      const cell = row.insertCell();

      cell.textContent = value;
    });
  });

  exportExcelButton.disabled = false;
}

function renderInterestSummary(result) {
  if (result.bankInterest > result.currentInterest) {
    currentInterestElement.hidden = true;
    bankInterestElement.hidden = false;
    bankInterestElement.textContent = "Переплата по кредиту в Банке составит: " + formatMoney(result.bankInterest);
    return;
  }

  currentInterestElement.hidden = false;
  bankInterestElement.hidden = false;
  currentInterestElement.textContent = "Переплата по текущим кредитам: " + formatMoney(result.currentInterest);
  bankInterestElement.textContent = "Переплата по новому кредиту в Банке: " + formatMoney(result.bankInterest);
}

function setError(element, message) {
  element.textContent = message;

  if (message) {
    element.classList.add("popup__input-error_visible");
  } else {
    element.classList.remove("popup__input-error_visible");
  }
}

function setFieldState(field, isInvalid) {
  if (!field) {
    return;
  }

  field.classList.toggle("popup__input-errorSa", isInvalid);
}

function updateProgramSelectors() {
  const classes = getRefinanceClasses(categorySelect.value);

  fillSelect(classSelect, classes, "Выберите условия");
  fillSelect(programSelect, [], "Выберите программу");
  termInput.value = "";
  if (currentDebtControl) currentDebtControl.reset();
  renderConditions();
  renderTotals();
}

function updateProgramList() {
  const programs = getRefinancePrograms(categorySelect.value, classSelect.value);

  fillSelect(programSelect, programs, "Выберите программу");
  termInput.value = "";
  if (currentDebtControl) currentDebtControl.reset();
  renderConditions();
  renderTotals();
}

function applyProgramLimits() {
  const product = getCurrentProduct();

  if (!product) {
    termInput.removeAttribute("min");
    termInput.removeAttribute("max");
    renderConditions();
    renderTotals();
    return;
  }

  termInput.min = product.minAge;
  termInput.max = product.maxAge;

  if (!termInput.value) {
    termInput.value = product.minAge;
  }

  renderConditions();
  renderTotals();
  validateDebtLimit(false);
}

function getDefaultProgramSelection() {
  const categories = getRefinanceCategories();

  for (const category of categories) {
    const classes = getRefinanceClasses(category);

    for (const classCategory of classes) {
      const programs = getRefinancePrograms(category, classCategory);

      if (programs.includes(DEFAULT_REFINANCE_PROGRAM)) {
        return {
          category: category,
          classCategory: classCategory,
          program: DEFAULT_REFINANCE_PROGRAM,
        };
      }
    }
  }

  return null;
}

function applyDefaultProgramSelection() {
  const selection = getDefaultProgramSelection();

  if (!selection) {
    return;
  }

  categorySelect.value = selection.category;
  fillSelect(classSelect, getRefinanceClasses(selection.category), "Выберите условия");
  classSelect.value = selection.classCategory;
  fillSelect(programSelect, getRefinancePrograms(selection.category, selection.classCategory), "Выберите программу");
  programSelect.value = selection.program;
  applyProgramLimits();
}

function createCreditRow() {
  creditIndex += 1;

  const row = document.createElement("tr");
  row.className = "economy-credit-row";
  row.innerHTML = [
    '<td><input class="economy-table-input economy-credit-name" type="text" value="Кредит ' + creditIndex + '"></td>',
    '<td><select class="economy-table-input economy-credit-type"><option value="annuity">Аннуитетный</option><option value="differentiated">Дифференцированный</option></select></td>',
    '<td><input class="economy-table-input economy-credit-principal economy-money" type="text" inputmode="decimal" placeholder="0"></td>',
    '<td><input class="economy-table-input economy-credit-rate" type="text" inputmode="decimal" placeholder="0"></td>',
    '<td><input class="economy-table-input economy-credit-end" type="date"></td>',
    '<td><button class="paramentsStavok__btn economy-remove-credit" type="button">Удалить</button></td>',
  ].join("");

  loansBody.appendChild(row);
  updateAddButtonState();
}

function updateAddButtonState() {
  const isLimitReached = getCreditRows().length >= MAX_CREDITS;

  addCreditButton.disabled = isLimitReached;
  addCreditButton.textContent = isLimitReached ? "Лимит 12 кредитов" : "Добавить кредит";
}

function validateSelection() {
  const product = getCurrentProduct();
  const termMonths = parseInt(termInput.value, 10);
  const rate = getCurrentRate();
  let isValid = true;

  setError(document.getElementById("economyCategoryError"), "");
  setError(document.getElementById("economyClassError"), "");
  setError(document.getElementById("economyProgramError"), "");
  setError(document.getElementById("economyTermError"), "");
  setError(totalCreditError, "");
  setFieldState(categorySelect, false);
  setFieldState(classSelect, false);
  setFieldState(programSelect, false);
  setFieldState(termInput, false);

  if (!categorySelect.value) {
    setError(document.getElementById("economyCategoryError"), "Выберите категорию клиента.");
    setFieldState(categorySelect, true);
    isValid = false;
  }

  if (!classSelect.value) {
    setError(document.getElementById("economyClassError"), "Выберите условия программы.");
    setFieldState(classSelect, true);
    isValid = false;
  }

  if (!programSelect.value || !product) {
    setError(document.getElementById("economyProgramError"), "Выберите программу рефинансирования.");
    setFieldState(programSelect, true);
    isValid = false;
  }

  if (!product || !termMonths || termMonths < product.minAge || termMonths > product.maxAge || !rate) {
    const message = product
      ? "Укажите срок от " + product.minAge + " до " + product.maxAge + " мес."
      : "Укажите срок нового кредита.";

    setError(document.getElementById("economyTermError"), message);
    setFieldState(termInput, true);
    isValid = false;
  }

  if (product) {
    const totalCredit = getTotalCredit();
    const minCredit = getMinCredit(product, { electronic: electronicInput.checked });
    const creditLimit = getProductCreditLimit(product);

    if (totalCredit < minCredit) {
      setError(totalCreditError, "Минимальная сумма кредита по выбранным условиям: " + formatMoney(minCredit));
      isValid = false;
    } else if (totalCredit > creditLimit) {
      setError(totalCreditError, "Максимальная сумма кредита по выбранным условиям: " + formatMoney(creditLimit));
      isValid = false;
    } else if (!validateDebtLimit(false)) {
      setError(totalCreditError, "");
      isValid = false;
    } else {
      setError(totalCreditError, "");
    }

    if (bankLoansInput.checked) {
      const minTotalForBankLoans = getDebtTotal() * BANK_REFINANCE_MIN_RATIO;

      if (totalCredit < minTotalForBankLoans) {
        setError(totalCreditError, "При рефинансировании кредитов Банка общая сумма кредита должна быть не менее " + formatMoneyPrecise(minTotalForBankLoans) + ".");
        isValid = false;
      }
    }
  }

  return isValid;
}

function collectCredits() {
  const rows = getCreditRows();
  const credits = [];
  let isValid = true;

  setError(loansError, "");

  rows.forEach(function (row) {
    const nameInput = row.querySelector(".economy-credit-name");
    const typeInput = row.querySelector(".economy-credit-type");
    const principalInput = row.querySelector(".economy-credit-principal");
    const rateInput = row.querySelector(".economy-credit-rate");
    const endInput = row.querySelector(".economy-credit-end");
    const principal = parseNumber(principalInput.value);
    const annualRate = parseRate(rateInput.value);
    const months = getMonthsToDate(endInput.value);

    setFieldState(principalInput, false);
    setFieldState(rateInput, false);
    setFieldState(endInput, false);

    if (principal <= 0) {
      setFieldState(principalInput, true);
      isValid = false;
    }

    if (annualRate < 0 || !rateInput.value) {
      setFieldState(rateInput, true);
      isValid = false;
    }

    if (months <= 0) {
      setFieldState(endInput, true);
      isValid = false;
    }

    credits.push({
      name: nameInput.value || "Кредит",
      paymentType: typeInput.value,
      principal: principal,
      annualRate: annualRate,
      months: months,
    });
  });

  if (!rows.length) {
    setError(loansError, "Добавьте хотя бы один рефинансируемый кредит.");
    return null;
  }

  if (!isValid) {
    setError(loansError, "Проверьте остаток долга, ставку и дату окончания по каждому кредиту.");
    return null;
  }

  return credits;
}

function calculate(evt) {
  evt.preventDefault();
  renderTotals();
  renderConditions();

  const credits = collectCredits();
  const selectionIsValid = validateSelection();
  const debtLimitIsValid = validateDebtLimit(true);

  if (!credits || !selectionIsValid || !debtLimitIsValid) {
    renderPaymentSchedule([]);
    return;
  }

  const rate = getCurrentRate();
  const totalCredit = getTotalCredit();
  const termMonths = parseInt(termInput.value, 10);
  const result = calculateRefinanceSavings({
    credits: credits,
    totalCredit: totalCredit,
    bankRate: rate.rate,
    termMonths: termMonths,
  });
  const schedule = calculateAnnuitySchedule(totalCredit, rate.rate, termMonths);

  resultElement.textContent = "Экономия на процентах при кредитовании в Банке составит: " + formatMoney(result.displaySavings);
  renderInterestSummary(result);
  paymentElement.textContent = "Ежемесячный платеж по новому кредиту: " + formatMoney(result.bankMonthlyPayment);
  analyticElement.textContent = result.rawSavings > 0 ? positiveAnalyticText : negativeAnalyticText;
  renderPaymentSchedule(schedule);
}

function handleTableInput(evt) {
  if (evt.target.classList.contains("economy-money")) {
    formatNumberInput(evt.target);
  }

  renderTotals();
  validateDebtLimit(false);
}

function handleMoneyBlur(evt) {
  if (evt.target.classList.contains("economy-money")) {
    formatNumberInput(evt.target);
    renderTotals();
    validateDebtLimit(false);
  }
}

function exportScheduleToExcel(evt) {
  evt.preventDefault();

  if (exportExcelButton.disabled || !paymentScheduleTable.tBodies[0].rows.length) {
    return;
  }

  if (typeof Table2Excel === "undefined") {
    alert("Экспорт в Excel временно недоступен. Обновите страницу и повторите попытку.");
    return;
  }

  const table2excel = new Table2Excel();

  table2excel.export(paymentScheduleTable);
}

currentDebtControl = initCurrentDebtControl({
  checkboxId: "economyCurrentDebtToggle",
  inputId: "economyCurrentDebtAmount",
  errorId: "economyCurrentDebtError",
  onChange: function () {
    renderTotals();
    validateDebtLimit(false);
  },
});

fillSelect(categorySelect, getRefinanceCategories(), "Выберите категорию");
fillSelect(classSelect, [], "Выберите условия");
fillSelect(programSelect, [], "Выберите программу");
applyDefaultProgramSelection();
createCreditRow();
renderConditions();
renderTotals();

categorySelect.addEventListener("change", updateProgramSelectors);
classSelect.addEventListener("change", updateProgramList);
programSelect.addEventListener("change", applyProgramLimits);
termInput.addEventListener("input", function () {
  renderConditions();
  renderTotals();
});
electronicInput.addEventListener("change", function () {
  renderConditions();
  renderTotals();
});
guarantorInput.addEventListener("change", function () {
  renderConditions();
  renderTotals();
  validateDebtLimit(false);
});
bankLoansInput.addEventListener("change", function () {
  renderTotals();
  validateDebtLimit(false);
});
extraAmountInput.addEventListener("input", function () {
  formatNumberInput(extraAmountInput);
  renderTotals();
  validateDebtLimit(false);
});
extraAmountInput.addEventListener("blur", function () {
  formatNumberInput(extraAmountInput);
  if (!extraAmountInput.value) {
    extraAmountInput.value = "0";
  }
  renderTotals();
  validateDebtLimit(false);
});
addCreditButton.addEventListener("click", createCreditRow);
loansBody.addEventListener("input", handleTableInput);
loansBody.addEventListener("change", renderTotals);
loansBody.addEventListener("focusout", handleMoneyBlur);
loansBody.addEventListener("click", function (evt) {
  if (!evt.target.classList.contains("economy-remove-credit")) {
    return;
  }

  if (getCreditRows().length === 1) {
    evt.target.closest(".economy-credit-row").querySelectorAll("input").forEach(function (input) {
      input.value = input.classList.contains("economy-credit-name") ? "Кредит 1" : "";
    });
  } else {
    evt.target.closest(".economy-credit-row").remove();
  }

  updateAddButtonState();
  renderTotals();
  validateDebtLimit(false);
});
form.addEventListener("submit", calculate);
exportExcelButton.addEventListener("click", exportScheduleToExcel);
